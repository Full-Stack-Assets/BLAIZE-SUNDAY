# Operations Runbook

## 1. Configure secrets

Create `.env.local` from `.env.example`. Generate a long random `OPERATOR_TOKEN`. Add the ElevenLabs key as `ELEVENLABS_API_KEY`; it is used only in Node.js route handlers and never returned to the browser. For production, add the same variables in Vercel project settings.

## 2. Create the Airtable control base

The intended schema is `config/airtable-schema.json`. It contains ten tables: Assets, Rights, Approvals, Opportunities, Production Jobs, Releases, Revenue, Campaigns, Exceptions, and Import Runs.

Run the provisioning script without `--commit` first. Dry-run lists intended tables but creates nothing:

```bash
node scripts/provision-airtable.mjs
```

After reviewing the target workspace and scopes, run with `--commit`. Record the returned base ID as `AIRTABLE_BASE_ID`. The Airtable token needs schema-write permission for provisioning and record-write permission for imports. Do not store the token in Airtable.

## 3. Inventory ElevenLabs

Use **Run safe inventory** first. It calls only read endpoints and returns unique counts plus warnings. It does not download audio, use generation credits, publish, or write Airtable records.

Review the count by asset type and unavailable-source warnings. Then use **Commit to Airtable**. Upserts use `ExternalKey`, so repeating an import updates a source record instead of creating duplicates.

Current automated source coverage:

| Asset class | Intake | Notes |
| --- | --- | --- |
| Voices | ElevenLabs API | Token pagination, up to 100 pages |
| TTS/STS/Studio/dubbing history | ElevenLabs API | Cursor pagination, up to 100,000 history entries |
| Studio projects | ElevenLabs API | Metadata only |
| Owned agents | ElevenLabs API | Cursor pagination; shared agents excluded by request |
| Music | Manual manifest | Public generated-history API does not enumerate it |
| Sound Effects | Manual manifest | Public generated-history API does not enumerate it |

## 4. Import Music and Sound Effects

Create a JSON manifest that validates against `config/manual-manifest.schema.json`. Use platform identifiers exactly as observed in ElevenLabs, plus a real ISO 8601 export timestamp. Send it to `/api/import/manual` in dry-run mode before committing.

Manual records are labeled `user_export`, not `api_observed`. Neither evidence class proves commercial rights.

## 5. Review the decision queue

New catalog records default to `RightsStatus = unknown`, no quality score, and no demand score. This is intentional. Add evidence in Rights, complete QA, and create a separate Approval record. Never rewrite imported source evidence to imply rights clearance.

## 6. Analytics

Set `NEXT_PUBLIC_POSTHOG_KEY` and the regional host to enable the four initial events:

| Event | Trigger | Allowed properties |
| --- | --- | --- |
| `catalog_import_started` | Operator starts an import | mode |
| `catalog_import_completed` | Import finishes | mode, total_assets, blocked |
| `approval_requested` | Future approval workflow | approval type, asset class |
| `exception_viewed` | Future exception workflow | severity, exception type |

Do not send API keys, scripts, customer text, voice samples, source prompts, consent files, or raw asset metadata to PostHog.

## 7. Incident response

- Rights dispute: block the asset and every release that references it; preserve evidence; notify the owner immediately.
- Authentication failure: rotate the affected token and review provider audit logs.
- Unexpected write volume: disable Airtable credentials in Vercel and run only dry inventories until reconciled.
- Partial import: keep successfully observed records, review warnings, then retry only the unavailable source.
- Platform suspension or payment failure: halt publication and commerce adapters; catalog inventory may remain read-only.


## Rights-gated production

`POST /api/produce` requires `Authorization: Bearer <OPERATOR_TOKEN>`.

The body is `{ "commit": false, "brief": { ... } }`. Dry-run is the default and returns a deterministic job ID, gate result, derivative plan, release-readiness decision, and `.agent_checkpoint` without calling ElevenLabs.

Live generation requires all of the following:

- `commit: true`
- `ELEVENLABS_API_KEY`
- a real `voiceId`
- `rights.status: "verified"`
- at least one rights evidence ID
- `operatorApproved: true`

The endpoint does not publish, charge customers, send email, approve rights, or create fake storage URLs.
