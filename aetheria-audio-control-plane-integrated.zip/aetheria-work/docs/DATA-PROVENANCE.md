# Data Provenance Standard

Every operating claim must identify how it became known.

| Evidence class | Meaning | May prove rights? |
| --- | --- | --- |
| `api_observed` | Returned by an authenticated provider API at `ObservedAt` | No |
| `user_export` | Present in a user-supplied platform export | No |
| `user_attested` | Explicitly stated by an authorized operator | Only as a review input |
| `inferred` | Computed or classified from other data | No |

The canonical key is `<platform>:<asset-type>:<source-id>`. Source IDs are never replaced by marketing titles. Observations may update descriptive metadata but must not silently change rights evidence or human approvals.

Unknown numbers remain null. In particular, the system must not convert missing revenue, quality, demand, conversion, usage, or cost observations to zero. Zero is a real measurement; null means not measured.

The uploaded source plan included illustrative asset IDs, URLs, prices, clearances, and performance improvements. They are treated as planning examples only and are not loaded into the operating database.

Raw generation text and audio are intentionally excluded from the first import. This reduces privacy and copyright exposure while establishing the catalog inventory. Independent master-file backup is a later, separately approved workflow.

