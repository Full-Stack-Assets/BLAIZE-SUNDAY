# Aetheria SongForge Integration Design

## Goal

Extend the existing Aetheria Audio IP Control Plane into a production-capable, rights-gated audio asset engine that can accept structured SongForge scripts, render audio through ElevenLabs when configured, preserve exact provenance, and create derivative/release plans without fabricating publication or revenue data.

## Architecture

The existing Next.js control plane remains the authoritative operator interface and API surface. A new production domain layer accepts a validated production brief, checks rights and approval gates, dispatches a provider adapter, records deterministic asset/job/checkpoint data, and returns a release-readiness result. SongForge is treated as a structured content-input adapter: interactive songwriting remains in-conversation, while the uploaded Python script remains an optional unattended batch writer outside the web runtime.

## Components

1. Production brief schema and types.
2. Rights-gated production state machine.
3. ElevenLabs speech adapter with deterministic dry-run support.
4. SongForge structured-script parser and import endpoint.
5. Derivative plan generator for podcast, YouTube, shorts, transcript, bundles, and subscriptions.
6. Airtable mapping extensions for production jobs, assets, rights records, releases, and exceptions.
7. Operator dashboard production panel and honest configuration states.
8. Checkpoint serialization for restart-safe continuation.

## Data Flow

SongForge script or direct production brief → validation → rights gate → production job → ElevenLabs adapter or dry-run → canonical asset result → derivative plan → release readiness → optional Airtable commit. No publishing, payment, email send, price change, or rights approval occurs automatically.

## Error Handling

Provider errors are normalized into retryable and terminal classes. Retryable failures increment attempt count and preserve an idempotency key. Rights failures create a blocked result and exception payload without calling generation providers. Missing credentials produce configuration errors, never fake audio URLs.

## Testing

Vitest covers schemas, rights gate behavior, idempotency, provider request mapping, SongForge parsing, derivative plans, checkpoint serialization, API authorization, and dashboard states. Existing tests must remain green. TypeScript and production build are required before packaging.
