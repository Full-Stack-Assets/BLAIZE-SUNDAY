# Aetheria SongForge Integration Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a rights-gated SongForge-to-ElevenLabs production workflow, derivative planning, checkpointing, Airtable mappings, and operator controls to the existing Aetheria control plane.

**Architecture:** Keep Next.js as the control plane and add focused production-domain modules. Validate all inputs with Zod, block provider calls until rights gates pass, support safe dry-runs, and expose provider-independent results that can later be committed to Airtable.

**Tech Stack:** Next.js 16, React 19, TypeScript 7, Zod 4, Vitest 4, ElevenLabs REST API, Airtable REST API.

## Global Constraints

- Never fabricate publication, revenue, analytics, rights, or provider identifiers.
- Interactive SongForge writing is performed in conversation; uploaded Python remains an optional unattended batch utility.
- Rights approval is mandatory before real generation or release readiness.
- Dry-run is the default for production and Airtable writes.
- Public publishing, payments, email sends, price changes, and legal approval remain human-gated.
- Existing import and dashboard behavior must remain backward compatible.

---

### Task 1: Production Domain Contracts

**Files:**
- Create: `src/production/types.ts`
- Create: `src/production/schema.ts`
- Test: `tests/production/schema.test.ts`

**Interfaces:**
- Produces: `ProductionBrief`, `ProductionResult`, `DerivativePlan`, `AgentCheckpoint`, `productionBriefSchema`.

- [ ] Write failing tests for valid and invalid production briefs.
- [ ] Run `npm test -- tests/production/schema.test.ts` and verify failure.
- [ ] Implement strict Zod schemas and inferred TypeScript types.
- [ ] Run the focused tests and verify pass.

### Task 2: Rights-Gated Production State Machine

**Files:**
- Create: `src/production/state-machine.ts`
- Test: `tests/production/state-machine.test.ts`

**Interfaces:**
- Consumes: `ProductionBrief`.
- Produces: `evaluateProductionGate(brief)` and `buildIdempotencyKey(brief)`.

- [ ] Write failing tests for approved, pending, blocked, and expired rights states.
- [ ] Verify provider execution is disallowed unless rights and operator approval pass.
- [ ] Implement deterministic gate and idempotency functions.
- [ ] Run focused tests.

### Task 3: ElevenLabs Production Adapter

**Files:**
- Create: `src/integrations/elevenlabs/produce.ts`
- Test: `tests/integrations/elevenlabs-produce.test.ts`

**Interfaces:**
- Produces: `buildElevenLabsSpeechRequest`, `produceSpeech`.

- [ ] Write failing request-mapping and dry-run tests.
- [ ] Implement request payload mapping without making network calls in dry-run.
- [ ] Implement configured live call with normalized errors and returned binary metadata.
- [ ] Run focused tests.

### Task 4: SongForge Structured Input Adapter

**Files:**
- Create: `src/production/songforge.ts`
- Test: `tests/production/songforge.test.ts`

**Interfaces:**
- Produces: `parseSongForgeScript(text)` returning a `ProductionBrief` seed and structured sections.

- [ ] Write failing tests using realistic SongForge headers and section tags.
- [ ] Implement parser for title, style directive, BPM, persona, lyrics, and duration target.
- [ ] Reject missing title, style, or lyrics instead of inventing values.
- [ ] Run focused tests.

### Task 5: Derivative and Release Planning

**Files:**
- Create: `src/production/derivatives.ts`
- Test: `tests/production/derivatives.test.ts`

**Interfaces:**
- Produces: `planDerivatives(result)` and `evaluateReleaseReadiness(result)`.

- [ ] Write failing tests for narration and song derivative plans.
- [ ] Implement podcast, YouTube, shorts, transcript, bundle, and subscription plans.
- [ ] Ensure plans are proposals only and never claim publication.
- [ ] Run focused tests.

### Task 6: Checkpoint Serialization

**Files:**
- Create: `src/production/checkpoint.ts`
- Test: `tests/production/checkpoint.test.ts`

**Interfaces:**
- Produces: `createAgentCheckpoint(result, nextTarget)`.

- [ ] Write failing deterministic checkpoint tests.
- [ ] Implement `.agent_checkpoint` payload with real IDs and statuses only.
- [ ] Run focused tests.

### Task 7: Production Orchestrator and API

**Files:**
- Create: `src/production/run-production.ts`
- Create: `src/app/api/produce/route.ts`
- Test: `tests/production/run-production.test.ts`
- Test: `tests/api/produce-route.test.ts`

**Interfaces:**
- Produces: `runProduction(input, dependencies)` and authenticated `POST /api/produce`.

- [ ] Write failing orchestration tests for blocked, dry-run, and successful provider paths.
- [ ] Implement orchestration with explicit dependency injection.
- [ ] Implement bearer-token API authorization and dry-run default.
- [ ] Run focused tests.

### Task 8: Airtable Mapping Extensions

**Files:**
- Modify: `src/integrations/airtable/map-records.ts`
- Modify: `src/integrations/airtable/client.ts`
- Modify: `config/airtable-schema.json`
- Test: `tests/integrations/airtable-production.test.ts`

**Interfaces:**
- Produces: mappings for Assets, Rights & Consent, Production Jobs, Releases, and Exceptions.

- [ ] Write failing tests for stable external keys and field mappings.
- [ ] Implement mappings without fabricating missing values.
- [ ] Add optional commit support behind existing Airtable configuration.
- [ ] Run focused tests.

### Task 9: Operator Production Panel

**Files:**
- Create: `src/components/production-panel.tsx`
- Modify: `src/components/dashboard.tsx`
- Modify: `src/app/globals.css`
- Test: `tests/ui/production-panel.test.tsx`

**Interfaces:**
- Produces: a production form with dry-run, configuration status, rights status, and result rendering.

- [ ] Write failing rendering tests for unconfigured, blocked, and ready states.
- [ ] Implement accessible operator controls and honest status messaging.
- [ ] Add the panel to the existing dashboard.
- [ ] Run focused tests.

### Task 10: Documentation, Environment, and Verification

**Files:**
- Modify: `.env.example`
- Modify: `README.md`
- Modify: `docs/OPERATIONS.md`
- Create: `docs/SONGFORGE-INTEGRATION.md`

**Interfaces:**
- Documents exact configuration, dry-run behavior, approval boundaries, and batch utility separation.

- [ ] Document new environment variables and endpoint.
- [ ] Document SongForge interactive and unattended modes.
- [ ] Run `npm run typecheck`.
- [ ] Run `npm test`.
- [ ] Run `npm run build`.
- [ ] Package the verified project as a ZIP.
