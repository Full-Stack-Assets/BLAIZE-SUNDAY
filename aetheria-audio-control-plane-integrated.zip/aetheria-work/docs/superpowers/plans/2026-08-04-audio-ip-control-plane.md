# Autonomous Audio IP Control Plane Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a deployable, testable control plane that inventories Nic's existing ElevenLabs catalog, enforces rights and quality gates, syncs approved operational records to Airtable, and measures real behavior without fabricated data.

**Architecture:** A Next.js App Router application provides the operator dashboard and authenticated server-side import endpoints. Focused TypeScript modules implement ElevenLabs pagination/normalization, evidence-aware rights gates, quality scoring, portfolio decisions, Airtable mapping, and conditional PostHog capture. ElevenLabs remains the source platform; Airtable is the operational system of record; no external publish, price, payment, rights approval, or deletion action is automatic.

**Tech Stack:** Node.js 22+, Next.js 16, React 19, TypeScript 5, Zod, Vitest, Testing Library, PostHog JS, Airtable REST adapters, Vercel.

## Global Constraints

- Import existing ElevenLabs voices, generated-history items, Studio projects, and owned agents before generating new inventory.
- ElevenLabs Music and Sound Effects cannot currently be enumerated through the public API; accept a verified manual-export manifest for those asset types and label the source accordingly.
- Never represent sample, planned, or inferred data as observed operating data.
- Require explicit human approval for rights, publication, pricing, spending, contracts, refunds above policy, and master-asset deletion.
- Keep API keys and tokens in environment variables; never persist them in source, logs, browser bundles, or Airtable fields.
- Default imports to dry-run until the operator explicitly enables Airtable writes.
- Every record must retain source platform, source identifier, observed timestamp, evidence class, and synchronization status.

---

### Task 1: Domain contracts and approval gates

**Files:**
- Create: `src/domain/types.ts`
- Create: `src/domain/gates.ts`
- Create: `src/domain/scoring.ts`
- Test: `tests/domain/gates.test.ts`
- Test: `tests/domain/scoring.test.ts`

**Interfaces:**
- Produces: `CanonicalAsset`, `RightsRecord`, `GateDecision`, `evaluateReleaseGate(asset, rights)`, and `scoreRevenueReadiness(asset)`.

- [ ] Write failing tests proving unknown rights block release, verified rights plus quality may proceed to human approval, and missing observations never receive invented scores.
- [ ] Run `npm test -- tests/domain` and confirm failures are caused by missing modules.
- [ ] Implement the minimal typed domain and deterministic gate/scoring rules.
- [ ] Run `npm test -- tests/domain` and confirm all domain tests pass.
- [ ] Commit the domain deliverable.

### Task 2: ElevenLabs catalog ingestion

**Files:**
- Create: `src/integrations/elevenlabs/client.ts`
- Create: `src/integrations/elevenlabs/normalize.ts`
- Create: `src/integrations/elevenlabs/types.ts`
- Create: `src/import/manual-manifest.ts`
- Test: `tests/integrations/elevenlabs.test.ts`
- Test: `tests/import/manual-manifest.test.ts`

**Interfaces:**
- Consumes: `CanonicalAsset` from Task 1.
- Produces: `ElevenLabsClient.listCatalog()`, `normalizeVoice`, `normalizeHistoryItem`, `normalizeProject`, `normalizeAgent`, and `parseManualManifest`.

- [ ] Write failing tests for voice token pagination, history cursor pagination, agent cursor pagination, normalization provenance, and strict manual manifest validation.
- [ ] Run the focused tests and observe the expected missing-module failures.
- [ ] Implement read-only API calls to `/v2/voices`, `/v1/history`, `/v1/studio`, and `/v1/convai/agents`, with bounded pagination and redacted errors.
- [ ] Implement manual manifest ingestion for music and SFX using `sourceEvidence: user_export`.
- [ ] Run focused tests and confirm they pass.
- [ ] Commit the ingestion deliverable.

### Task 3: Airtable schema and synchronization adapter

**Files:**
- Create: `config/airtable-schema.json`
- Create: `src/integrations/airtable/client.ts`
- Create: `src/integrations/airtable/map-records.ts`
- Create: `scripts/provision-airtable.mjs`
- Test: `tests/integrations/airtable.test.ts`

**Interfaces:**
- Consumes: canonical records from Tasks 1 and 2.
- Produces: `AirtableClient.upsertAssets(records, dryRun)` and explicit tables for Opportunities, Assets, Rights, Production Jobs, Releases, Revenue, Campaigns, Exceptions, Import Runs, and Approvals.

- [ ] Write failing tests for field mapping, stable external-key generation, dry-run behavior, batching at ten records, and secret-field rejection.
- [ ] Run the focused tests and observe expected failures.
- [ ] Implement the schema, mapping, provisioning plan, and REST upsert adapter.
- [ ] Run focused tests and confirm they pass.
- [ ] Commit the Airtable deliverable.

### Task 4: Import orchestration and API routes

**Files:**
- Create: `src/import/run-import.ts`
- Create: `src/app/api/health/route.ts`
- Create: `src/app/api/import/elevenlabs/route.ts`
- Create: `src/app/api/import/manual/route.ts`
- Test: `tests/import/run-import.test.ts`

**Interfaces:**
- Consumes: ElevenLabs and Airtable adapters.
- Produces: `runElevenLabsImport(dependencies, options)` returning counts, warnings, gate totals, and write status without exposing secrets or copyrighted source text.

- [ ] Write failing orchestration tests for dry-run, explicit commit, partial-source failure, deduplication, and missing-credential responses.
- [ ] Run focused tests and observe failures.
- [ ] Implement import orchestration and Node.js route handlers with an operator-token guard.
- [ ] Run focused tests and confirm they pass.
- [ ] Commit the import API deliverable.

### Task 5: Operator dashboard and analytics

**Files:**
- Create: `src/app/layout.tsx`
- Create: `src/app/page.tsx`
- Create: `src/app/globals.css`
- Create: `src/components/dashboard.tsx`
- Create: `src/components/import-panel.tsx`
- Create: `src/analytics/posthog.ts`
- Test: `tests/ui/dashboard.test.tsx`

**Interfaces:**
- Consumes: import summary and environment readiness.
- Produces: a responsive dashboard with truthful zero states, gate explanations, source coverage, and conditional PostHog events.

- [ ] Write failing UI tests for empty-catalog language, unconfigured integrations, rights-blocked counts, and absence of fake revenue metrics.
- [ ] Run UI tests and observe failures.
- [ ] Implement the dashboard and conditional `catalog_import_started`, `catalog_import_completed`, `approval_requested`, and `exception_viewed` events.
- [ ] Run UI tests and confirm they pass.
- [ ] Commit the dashboard deliverable.

### Task 6: Deployment, operations, and verification

**Files:**
- Create: `.env.example`
- Create: `vercel.json`
- Create: `.github/workflows/ci.yml`
- Create: `docs/OPERATIONS.md`
- Create: `docs/DATA-PROVENANCE.md`
- Create: `docs/RIGHTS-AND-APPROVALS.md`
- Create: `README.md`

**Interfaces:**
- Produces: reproducible setup, safe environment configuration, CI gates, scheduled dry-run import capability, and operator procedures.

- [ ] Document the exact environment variables, Airtable setup, ElevenLabs import coverage, music/SFX manual workflow, approval matrix, backup policy, and PostHog event schema.
- [ ] Add CI that installs from lockfile, type-checks, tests, and builds.
- [ ] Run `npm run typecheck`, `npm test`, and `npm run build` on the final tree.
- [ ] Scan tracked files for secret patterns and placeholder/fabricated operating data.
- [ ] Commit the verified release candidate and preserve the feature branch for the user's integration decision.

