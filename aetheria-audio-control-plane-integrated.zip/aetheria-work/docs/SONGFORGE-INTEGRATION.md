# SongForge Integration

Aetheria supports two deliberately separate SongForge modes.

## Interactive mode

The assistant writes the complete song script in conversation. No external LLM API is called to create lyrics. Export the finished script with explicit `TITLE`, `PERSONA`, `STYLE`, and structured lyric sections, then submit it to Aetheria as an approved production brief.

## Unattended batch mode

`tools/songforge/songforge-batch.py` preserves the uploaded server utility. It may call an OpenAI-compatible API for unattended batch loops when the operator intentionally configures `LLM_API_KEY`, `LLM_BASE_URL`, and `LLM_MODEL`. It is not imported into the Next.js runtime and does not bypass Aetheria rights or publication gates.

## Production path

1. Create or import a SongForge script.
2. Assign a real asset ID and actual ElevenLabs voice ID.
3. Record at least one rights-evidence identifier.
4. Set `operatorApproved` only after review.
5. Call `POST /api/produce` with `commit:false` for a dry run.
6. Call the same endpoint with `commit:true` for live ElevenLabs generation.
7. Review the derivative plan and publication decision separately.

The production endpoint never claims a public URL because ElevenLabs text-to-speech returns audio bytes, not durable hosted storage. Live responses include the returned audio as base64 plus observed byte count and content type. Persist the file to an approved storage adapter before publication.
