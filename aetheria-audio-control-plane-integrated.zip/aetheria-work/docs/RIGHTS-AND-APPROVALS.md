# Rights and Approval Policy

## Automated gates

An asset is blocked when commercial rights evidence is missing or expired, quality is unmeasured or below 85, or release metadata is incomplete. Passing those checks does not publish anything; it moves the asset to `approval_required`.

## Human-controlled actions

| Action | Required approval |
| --- | --- |
| Verify consent or commercial rights | Rights reviewer |
| Publish to ElevenLabs, Shopify, or another channel | Publisher |
| Change license terms or a price outside policy | Owner |
| Start paid media or raise budget | Owner |
| Issue a refund above policy | Owner |
| Send high-volume outreach | Owner or compliance reviewer |
| Sign a contract or enterprise license | Owner/legal reviewer |
| Delete a master asset | Owner, with recoverable backup verified |

Approval records must identify the related canonical key, approval type, decision, decision-maker, timestamp, and notes. An imported label, filename, marketplace state, or model category is never a substitute for consent evidence.

## Quality threshold

The initial release threshold is 85/100. A future QA adapter should measure clipping, noise, abrupt cuts, pronunciation, silence, loudness, transcript accuracy, duration, brand tone, and metadata completeness. Until those measurements exist, `QualityScore` remains null and the asset remains blocked.

