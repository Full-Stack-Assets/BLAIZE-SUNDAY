import fs from "node:fs/promises";

const schema = JSON.parse(await fs.readFile(new URL("../config/airtable-schema.json", import.meta.url), "utf8"));
if (!process.env.AIRTABLE_TOKEN || !process.env.AIRTABLE_WORKSPACE_ID) {
  console.error("AIRTABLE_TOKEN and AIRTABLE_WORKSPACE_ID are required. No changes were made.");
  process.exit(1);
}

if (!process.argv.includes("--commit")) {
  console.log(JSON.stringify({ mode: "dry-run", base: schema.name, tables: schema.tables.map((table) => table.name) }, null, 2));
  process.exit(0);
}

const response = await fetch("https://api.airtable.com/v0/meta/bases", {
  method: "POST",
  headers: { authorization: `Bearer ${process.env.AIRTABLE_TOKEN}`, "content-type": "application/json" },
  body: JSON.stringify({ name: schema.name, workspaceId: process.env.AIRTABLE_WORKSPACE_ID, tables: schema.tables.map((table) => ({ name: table.name, fields: table.fields.map(([name, type]) => ({ name, type })) })) })
});
if (!response.ok) throw new Error(`Airtable provisioning failed (${response.status})`);
const result = await response.json();
console.log(JSON.stringify({ mode: "committed", baseId: result.id, name: result.name }, null, 2));

