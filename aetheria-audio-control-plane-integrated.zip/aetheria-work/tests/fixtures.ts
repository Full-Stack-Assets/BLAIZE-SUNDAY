import type { CanonicalAsset } from "@/domain/types";

export function asset(overrides: Partial<CanonicalAsset> = {}): CanonicalAsset {
  return {
    externalKey: "elevenlabs:voice:voice-1",
    sourcePlatform: "elevenlabs",
    sourceId: "voice-1",
    sourceEvidence: "api_observed",
    observedAt: "2026-08-04T12:00:00.000Z",
    assetType: "voice",
    title: "Voice One",
    rightsStatus: "unknown",
    qualityScore: null,
    metadataComplete: false,
    demandScore: null,
    distributionFlexibility: null,
    rightsSimplicity: null,
    rawMetadata: {},
    ...overrides
  };
}

