import { describe, expect, it } from "vitest";
import { evaluateReleaseReadiness, planDerivatives } from "@/production/derivatives";
import type { ProductionResult } from "@/production/types";

const result: ProductionResult = {
  assetId: "A-1", jobId: "J-1", idempotencyKey: "key", status: "produced", provider: "elevenlabs",
  outputUrl: "https://example.invalid/master.mp3", contentType: "audio/mpeg", bytes: 123, gate: { allowed: true, state: "ready", reasons: [] },
  rightsStatus: "verified", operatorApproved: true, assetType: "narration", title: "Title"
};

describe("derivative planning", () => {
  it("plans narration derivatives without claiming publication", () => {
    const plan = planDerivatives(result);
    expect(plan.items.map((x) => x.kind)).toContain("podcast");
    expect(plan.items.every((x) => x.status === "planned")).toBe(true);
  });

  it("requires human publication approval", () => {
    expect(evaluateReleaseReadiness(result).status).toBe("approval_required");
  });
});
