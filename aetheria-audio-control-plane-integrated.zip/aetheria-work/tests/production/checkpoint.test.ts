import { describe, expect, it } from "vitest";
import { createAgentCheckpoint } from "@/production/checkpoint";
import type { ProductionResult } from "@/production/types";

const result: ProductionResult = { assetId: "A-1", jobId: "J-1", idempotencyKey: "key", status: "planned", provider: "elevenlabs", outputUrl: null, contentType: null, bytes: null, gate: { allowed: true, state: "ready", reasons: [] }, rightsStatus: "verified", operatorApproved: true, assetType: "song", title: "Song" };

describe("checkpoint", () => {
  it("serializes only observed execution state", () => {
    const checkpoint = createAgentCheckpoint(result, { assetId: "A-2", action: "generate" }, "2026-08-06T09:00:00.000Z");
    expect(checkpoint[".agent_checkpoint"].lastSuccessfulAsset).toBeNull();
    expect(checkpoint[".agent_checkpoint"].nextExecutionTarget.assetId).toBe("A-2");
  });
});
