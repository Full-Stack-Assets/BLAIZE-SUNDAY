import { describe, expect, it } from "vitest";
import { buildIdempotencyKey, evaluateProductionGate } from "@/production/state-machine";
import type { ProductionBrief } from "@/production/types";

const brief: ProductionBrief = {
  assetId: "STOIC-MED-001", title: "Title", assetType: "narration", script: "Script", voiceId: "voice_1",
  modelId: "eleven_multilingual_v2", rights: { status: "verified", evidenceIds: ["e1"] }, operatorApproved: true,
  metadata: { language: "en" }
};

describe("production state machine", () => {
  it("allows production only with verified rights and operator approval", () => {
    expect(evaluateProductionGate(brief)).toEqual({ allowed: true, state: "ready", reasons: [] });
    expect(evaluateProductionGate({ ...brief, operatorApproved: false }).state).toBe("approval_required");
    expect(evaluateProductionGate({ ...brief, rights: { status: "restricted", evidenceIds: ["e1"] } }).state).toBe("blocked");
  });

  it("builds a deterministic idempotency key", () => {
    expect(buildIdempotencyKey(brief)).toBe(buildIdempotencyKey({ ...brief }));
  });
});
