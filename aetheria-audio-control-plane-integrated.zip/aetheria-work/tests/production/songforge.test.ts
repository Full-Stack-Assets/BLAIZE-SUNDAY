import { describe, expect, it } from "vitest";
import { parseSongForgeScript } from "@/production/songforge";

const script = `# TITLE: Neon County Line\n# PERSONA: Vic Marrow\n# STYLE: heartland rock, 124 BPM\n# TARGET DURATION: 2:20\n\n[Verse 1]\nHeadlights cut the rain\n\n[Chorus]\nWe ride the neon county line`;

describe("SongForge parser", () => {
  it("extracts only explicitly supplied song metadata", () => {
    const parsed = parseSongForgeScript(script);
    expect(parsed.title).toBe("Neon County Line");
    expect(parsed.persona).toBe("Vic Marrow");
    expect(parsed.bpm).toBe(124);
    expect(parsed.lyrics).toContain("[Chorus]");
  });

  it("rejects incomplete scripts", () => {
    expect(() => parseSongForgeScript("[Verse]\nwords")).toThrow();
  });
});
