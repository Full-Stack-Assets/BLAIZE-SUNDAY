import { describe, expect, it } from "vitest";
import { productionBriefSchema } from "@/production/schema";

const valid = {
  assetId: "STOIC-MED-001",
  title: "The Dichotomy of Control",
  assetType: "narration",
  script: "A complete original script.",
  voiceId: "voice_real_123",
  modelId: "eleven_multilingual_v2",
  rights: { status: "verified", evidenceIds: ["consent-001"] },
  operatorApproved: true,
  metadata: { language: "en", category: "wellness" }
};

describe("productionBriefSchema", () => {
  it("accepts a rights-approved brief", () => {
    expect(productionBriefSchema.parse(valid).assetId).toBe("STOIC-MED-001");
  });

  it("rejects missing provenance instead of inventing it", () => {
    expect(() => productionBriefSchema.parse({ ...valid, rights: { status: "verified", evidenceIds: [] } })).toThrow();
  });
});
