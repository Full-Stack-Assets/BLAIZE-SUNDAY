import { describe, expect, it } from "vitest";
import { runProduction } from "@/production/run-production";
import type { ProductionBrief } from "@/production/types";

const brief: ProductionBrief = { assetId:"A-1", title:"Title", assetType:"narration", script:"Hello", voiceId:"v1", modelId:"eleven_multilingual_v2", rights:{status:"verified", evidenceIds:["e1"]}, operatorApproved:true, metadata:{language:"en"} };

describe("runProduction", () => {
  it("does not call providers when rights are blocked", async () => {
    let called = false;
    const fetcher: typeof fetch = async () => { called = true; return new Response(); };
    const result = await runProduction({ ...brief, rights: { status:"restricted", evidenceIds:["e1"] } }, { apiKey:"key", dryRun:false, fetcher });
    expect(result.status).toBe("blocked");
    expect(called).toBe(false);
  });

  it("defaults to a truthful planned result in dry-run", async () => {
    const result = await runProduction(brief, { apiKey:"", dryRun:true });
    expect(result.status).toBe("planned");
    expect(result.outputUrl).toBeNull();
  });
});
