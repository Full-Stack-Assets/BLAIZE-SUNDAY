import { describe, expect, it, vi } from "vitest";
import { AirtableClient } from "@/integrations/airtable/client";
import { mapAssetRecord } from "@/integrations/airtable/map-records";
import { asset } from "../fixtures";

describe("Airtable sync", () => {
  it("maps canonical provenance and excludes raw secret-like fields", () => {
    const record = mapAssetRecord(asset({ rawMetadata: { xi_api_key: "must-not-leak", safe: "ok" } }));
    expect(record.fields.ExternalKey).toBe("elevenlabs:voice:voice-1");
    expect(JSON.stringify(record)).not.toContain("must-not-leak");
  });

  it("dry run performs no network writes", async () => {
    const fetcher = vi.fn();
    const client = new AirtableClient({ token: "token", baseId: "app1", fetcher });
    const result = await client.upsertAssets([asset()], true);
    expect(result).toMatchObject({ planned: 1, written: 0, dryRun: true });
    expect(fetcher).not.toHaveBeenCalled();
  });

  it("chunks writes at ten records", async () => {
    const fetcher = vi.fn().mockResolvedValue(new Response(JSON.stringify({ records: [] })));
    const client = new AirtableClient({ token: "token", baseId: "app1", fetcher });
    await client.upsertAssets(Array.from({ length: 21 }, (_, i) => asset({ sourceId: `v${i}`, externalKey: `elevenlabs:voice:v${i}` })), false);
    expect(fetcher).toHaveBeenCalledTimes(3);
  });
});

