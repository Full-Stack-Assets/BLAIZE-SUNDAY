import { describe, expect, it } from "vitest";
import { mapProductionBundle } from "@/integrations/airtable/map-records";
import type { ProductionBrief, ProductionResult } from "@/production/types";

const brief: ProductionBrief = { assetId:"A-1", title:"Title", assetType:"narration", script:"Hello", voiceId:"v1", modelId:"m1", rights:{status:"verified", evidenceIds:["e1"]}, operatorApproved:true, metadata:{language:"en"} };
const result: ProductionResult = { assetId:"A-1", jobId:"J-1", idempotencyKey:"key", title:"Title", assetType:"narration", status:"planned", provider:"elevenlabs", outputUrl:null, contentType:null, bytes:null, gate:{allowed:true,state:"ready",reasons:[]}, rightsStatus:"verified", operatorApproved:true };

describe("production Airtable mapping", () => {
  it("uses stable IDs and never invents provider output", () => {
    const bundle = mapProductionBundle(brief, result, "2026-08-06T09:00:00.000Z");
    expect(bundle.asset.fields.ExternalKey).toBe("aetheria:A-1");
    expect(bundle.job.fields.JobID).toBe("J-1");
    expect(JSON.stringify(bundle)).not.toContain("http");
  });
});
