import { describe, expect, it } from "vitest";
import { buildElevenLabsSpeechRequest, produceSpeech } from "@/integrations/elevenlabs/produce";
import type { ProductionBrief } from "@/production/types";

const brief: ProductionBrief = {
  assetId: "A-1", title: "Title", assetType: "narration", script: "Hello world", voiceId: "voice_1",
  modelId: "eleven_multilingual_v2", rights: { status: "verified", evidenceIds: ["e1"] }, operatorApproved: true,
  metadata: { language: "en" }, voiceSettings: { stability: 0.8, similarityBoost: 0.9, style: 0.1, useSpeakerBoost: true }
};

describe("ElevenLabs production adapter", () => {
  it("maps a production brief to the API payload", () => {
    expect(buildElevenLabsSpeechRequest(brief)).toMatchObject({ text: "Hello world", model_id: "eleven_multilingual_v2", voice_settings: { stability: 0.8, similarity_boost: 0.9 } });
  });

  it("returns a truthful dry-run without a fake audio URL", async () => {
    const result = await produceSpeech(brief, { apiKey: "", dryRun: true });
    expect(result.status).toBe("planned");
    expect(result.outputUrl).toBeNull();
  });
});
