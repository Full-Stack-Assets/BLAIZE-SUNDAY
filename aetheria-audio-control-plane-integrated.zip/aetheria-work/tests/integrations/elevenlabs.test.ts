import { describe, expect, it, vi } from "vitest";
import { ElevenLabsClient } from "@/integrations/elevenlabs/client";
import { normalizeHistoryItem, normalizeVoice } from "@/integrations/elevenlabs/normalize";

describe("ElevenLabs catalog client", () => {
  it("paginates voices using next_page_token", async () => {
    const fetcher = vi.fn()
      .mockResolvedValueOnce(new Response(JSON.stringify({ voices: [{ voice_id: "v1", name: "One" }], has_more: true, next_page_token: "next" })))
      .mockResolvedValueOnce(new Response(JSON.stringify({ voices: [{ voice_id: "v2", name: "Two" }], has_more: false })));
    const client = new ElevenLabsClient({ apiKey: "secret", fetcher });
    const voices = await client.listVoices();
    expect(voices.map((v) => v.voice_id)).toEqual(["v1", "v2"]);
    expect(fetcher.mock.calls[1][0]).toContain("next_page_token=next");
  });

  it("paginates history using start_after_history_item_id", async () => {
    const fetcher = vi.fn()
      .mockResolvedValueOnce(new Response(JSON.stringify({ history: [{ history_item_id: "h1" }], has_more: true, last_history_item_id: "h1" })))
      .mockResolvedValueOnce(new Response(JSON.stringify({ history: [{ history_item_id: "h2" }], has_more: false })));
    const client = new ElevenLabsClient({ apiKey: "secret", fetcher });
    expect((await client.listHistory()).length).toBe(2);
    expect(fetcher.mock.calls[1][0]).toContain("start_after_history_item_id=h1");
  });

  it("normalizes provenance without claiming rights", () => {
    const observedAt = "2026-08-04T12:00:00.000Z";
    expect(normalizeVoice({ voice_id: "v1", name: "One", category: "cloned" }, observedAt)).toMatchObject({
      externalKey: "elevenlabs:voice:v1", sourceEvidence: "api_observed", rightsStatus: "unknown"
    });
    expect(normalizeHistoryItem({ history_item_id: "h1", voice_name: "One", source: "TTS" }, observedAt)).toMatchObject({
      externalKey: "elevenlabs:generation:h1", sourceId: "h1"
    });
  });
});

