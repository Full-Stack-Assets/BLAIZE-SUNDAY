import { describe, expect, it, vi } from "vitest";
import { runElevenLabsImport } from "@/import/run-import";
import { asset } from "../fixtures";

describe("import orchestration", () => {
  it("deduplicates catalog records and defaults to dry run", async () => {
    const sync = vi.fn().mockResolvedValue({ planned: 1, written: 0, dryRun: true });
    const result = await runElevenLabsImport({
      readCatalog: async () => ({ assets: [asset(), asset()], warnings: [] }),
      syncAssets: sync
    }, { commit: false });
    expect(result.totalAssets).toBe(1);
    expect(result.writeStatus).toBe("dry_run");
    expect(sync).toHaveBeenCalledWith(expect.any(Array), true);
  });

  it("keeps partial results and reports unavailable sources", async () => {
    const result = await runElevenLabsImport({
      readCatalog: async () => ({ assets: [asset()], warnings: ["Studio projects unavailable"] }),
      syncAssets: async () => ({ planned: 1, written: 1, dryRun: false })
    }, { commit: true });
    expect(result.warnings).toContain("Studio projects unavailable");
    expect(result.writeStatus).toBe("committed");
  });
});

