import { describe, expect, it } from "vitest";
import { parseManualManifest } from "@/import/manual-manifest";

describe("manual ElevenLabs export manifest", () => {
  it("accepts music and SFX exports and labels their evidence", () => {
    const [item] = parseManualManifest({ version: 1, exportedAt: "2026-08-04T12:00:00.000Z", assets: [{ type: "music", id: "m1", title: "Track" }] });
    expect(item.sourceEvidence).toBe("user_export");
    expect(item.externalKey).toBe("elevenlabs:music:m1");
  });

  it("rejects unsupported or incomplete entries", () => {
    expect(() => parseManualManifest({ version: 1, exportedAt: "bad", assets: [{ type: "voice" }] })).toThrow();
  });
});

