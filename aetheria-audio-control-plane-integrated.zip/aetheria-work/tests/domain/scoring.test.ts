import { describe, expect, it } from "vitest";
import { scoreRevenueReadiness } from "@/domain/scoring";
import { asset } from "../fixtures";

describe("revenue readiness", () => {
  it("does not invent a score when required observations are absent", () => {
    expect(scoreRevenueReadiness(asset()).score).toBeNull();
  });

  it("returns a deterministic observed-data score", () => {
    const result = scoreRevenueReadiness(asset({
      qualityScore: 90,
      metadataComplete: true,
      demandScore: 80,
      distributionFlexibility: 70,
      rightsSimplicity: 100
    }));
    expect(result.score).toBe(84);
    expect(result.basis).toBe("observed");
  });
});

