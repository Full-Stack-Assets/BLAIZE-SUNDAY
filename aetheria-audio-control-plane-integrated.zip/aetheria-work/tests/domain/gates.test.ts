import { describe, expect, it } from "vitest";
import { evaluateReleaseGate } from "@/domain/gates";
import { asset } from "../fixtures";

describe("release gate", () => {
  it("blocks assets without verified commercial rights", () => {
    const decision = evaluateReleaseGate(asset(), { status: "unknown", evidenceIds: [] });
    expect(decision.status).toBe("blocked");
    expect(decision.reasons).toContain("Commercial rights are not verified");
  });

  it("requires a human publication approval after automated gates pass", () => {
    const decision = evaluateReleaseGate(
      asset({ qualityScore: 94, metadataComplete: true }),
      { status: "verified", evidenceIds: ["consent-1"] }
    );
    expect(decision.status).toBe("approval_required");
    expect(decision.requiredApproval).toBe("publish");
  });
});

