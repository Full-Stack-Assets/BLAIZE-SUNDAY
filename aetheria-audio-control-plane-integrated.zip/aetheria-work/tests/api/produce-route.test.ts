import { describe, expect, it } from "vitest";
import { POST } from "@/app/api/produce/route";

describe("POST /api/produce", () => {
  it("rejects unauthorized requests", async () => {
    process.env.OPERATOR_TOKEN = "secret";
    const response = await POST(new Request("http://localhost/api/produce", { method:"POST", body:"{}", headers:{"content-type":"application/json"} }));
    expect(response.status).toBe(401);
  });
});
