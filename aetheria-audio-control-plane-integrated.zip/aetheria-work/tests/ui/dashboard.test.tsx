import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { Dashboard } from "@/components/dashboard";

describe("operator dashboard", () => {
  it("renders a truthful empty state without invented revenue", () => {
    const html = renderToStaticMarkup(<Dashboard summary={{ totalAssets: 0, blocked: 0, approvalRequired: 0, ready: 0, lastImportAt: null }} readiness={{ elevenlabs: false, airtable: false, posthog: false }} />);
    expect(html).toContain("No catalog data imported yet");
    expect(html).toContain("ElevenLabs not configured");
    expect(html).not.toContain("$0");
  });
});

