import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { ProductionPanel } from "@/components/production-panel";

describe("ProductionPanel", () => {
  it("honestly disables live generation when ElevenLabs is not configured", () => {
    const html = renderToStaticMarkup(<ProductionPanel configured={false} />);
    expect(html).toContain("Live generation is disabled");
    expect(html).toContain("disabled");
  });
});
