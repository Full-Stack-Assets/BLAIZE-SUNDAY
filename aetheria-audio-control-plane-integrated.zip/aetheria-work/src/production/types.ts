import type { RightsStatus } from "@/domain/types";

export type ProductionAssetType = "narration" | "song" | "meditation" | "podcast" | "audiobook" | "sound_bed" | "voiceover";

export interface VoiceSettings {
  stability?: number;
  similarityBoost?: number;
  style?: number;
  useSpeakerBoost?: boolean;
}

export interface ProductionBrief {
  assetId: string;
  title: string;
  assetType: ProductionAssetType;
  script: string;
  voiceId: string;
  modelId: string;
  rights: {
    status: RightsStatus;
    evidenceIds: string[];
    restrictions?: string[];
    expiresAt?: string | null;
  };
  operatorApproved: boolean;
  metadata: {
    language: string;
    category?: string;
    persona?: string;
    style?: string;
    bpm?: number;
    targetDurationSeconds?: number;
    source?: "direct" | "songforge";
  };
  voiceSettings?: VoiceSettings;
}

export interface ProductionGate {
  allowed: boolean;
  state: "blocked" | "approval_required" | "ready";
  reasons: string[];
}

export interface ProductionResult {
  assetId: string;
  jobId: string;
  idempotencyKey: string;
  title: string;
  assetType: ProductionAssetType;
  status: "blocked" | "planned" | "produced" | "failed";
  provider: "elevenlabs";
  outputUrl: string | null;
  contentType: string | null;
  bytes: number | null;
  audioBase64?: string;
  gate: ProductionGate;
  rightsStatus: RightsStatus;
  operatorApproved: boolean;
  error?: { code: string; message: string; retryable: boolean };
}

export type DerivativeKind = "podcast" | "youtube" | "shorts" | "transcript" | "bundle" | "subscription" | "instrumental" | "stems";
export interface DerivativePlan {
  sourceAssetId: string;
  items: Array<{ kind: DerivativeKind; status: "planned"; requiresApproval: true; notes: string }>;
}

export interface AgentCheckpoint {
  ".agent_checkpoint": {
    systemId: "aetheria_audio_engine_01";
    timestampUtc: string;
    lastSuccessfulAsset: string | null;
    activeStateProtocol: "STATE_GREEN" | "STATE_AMBER" | "STATE_RED";
    pipelineStatus: ProductionResult["status"];
    nextExecutionTarget: { assetId: string; action: string };
    idempotencyKey: string;
  };
}
