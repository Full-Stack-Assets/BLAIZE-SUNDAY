import type { AgentCheckpoint, ProductionResult } from "./types";

export function createAgentCheckpoint(
  result: ProductionResult,
  nextTarget: { assetId: string; action: string },
  timestampUtc = new Date().toISOString()
): AgentCheckpoint {
  const activeStateProtocol = result.status === "failed" || result.status === "blocked" ? "STATE_RED" : result.status === "planned" ? "STATE_AMBER" : "STATE_GREEN";
  return {
    ".agent_checkpoint": {
      systemId: "aetheria_audio_engine_01",
      timestampUtc,
      lastSuccessfulAsset: result.status === "produced" ? result.assetId : null,
      activeStateProtocol,
      pipelineStatus: result.status,
      nextExecutionTarget: nextTarget,
      idempotencyKey: result.idempotencyKey
    }
  };
}
