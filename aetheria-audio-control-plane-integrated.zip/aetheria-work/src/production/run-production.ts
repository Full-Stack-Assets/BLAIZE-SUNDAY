import type { ProductionBrief, ProductionResult } from "./types";
import { buildIdempotencyKey, evaluateProductionGate } from "./state-machine";
import { produceSpeech } from "@/integrations/elevenlabs/produce";

export interface ProductionDependencies {
  apiKey: string;
  dryRun: boolean;
  fetcher?: typeof fetch;
  makeJobId?: () => string;
}

export async function runProduction(brief: ProductionBrief, dependencies: ProductionDependencies): Promise<ProductionResult> {
  const gate = evaluateProductionGate(brief);
  const idempotencyKey = buildIdempotencyKey(brief);
  const jobId = dependencies.makeJobId?.() ?? `job_${idempotencyKey.slice(5, 21)}`;
  const base = {
    assetId: brief.assetId,
    jobId,
    idempotencyKey,
    title: brief.title,
    assetType: brief.assetType,
    provider: "elevenlabs" as const,
    outputUrl: null,
    gate,
    rightsStatus: brief.rights.status,
    operatorApproved: brief.operatorApproved
  };
  if (!gate.allowed) return { ...base, status: "blocked", contentType: null, bytes: null };
  try {
    const provider = await produceSpeech(brief, { apiKey: dependencies.apiKey, dryRun: dependencies.dryRun, fetcher: dependencies.fetcher });
    return { ...base, status: provider.status, contentType: provider.contentType, bytes: provider.bytes, audioBase64: provider.audioBase64 };
  } catch (error) {
    const value = error as Error & { code?: string; retryable?: boolean };
    return {
      ...base,
      status: "failed",
      contentType: null,
      bytes: null,
      error: { code: value.code ?? "PRODUCTION_ERROR", message: value.message || "Production failed", retryable: value.retryable === true }
    };
  }
}
