import { createHash } from "node:crypto";
import type { ProductionBrief, ProductionGate } from "./types";

export function evaluateProductionGate(brief: ProductionBrief, now = Date.now()): ProductionGate {
  const reasons: string[] = [];
  if (brief.rights.status !== "verified") reasons.push(`Rights status is ${brief.rights.status}, not verified`);
  if (brief.rights.evidenceIds.length === 0) reasons.push("At least one rights evidence ID is required");
  if (brief.rights.expiresAt && new Date(brief.rights.expiresAt).getTime() <= now) reasons.push("Rights evidence is expired");
  if (reasons.length > 0) return { allowed: false, state: "blocked", reasons };
  if (!brief.operatorApproved) return { allowed: false, state: "approval_required", reasons: ["Operator approval is required before generation"] };
  return { allowed: true, state: "ready", reasons: [] };
}

export function buildIdempotencyKey(brief: ProductionBrief): string {
  const canonical = JSON.stringify({
    assetId: brief.assetId,
    assetType: brief.assetType,
    modelId: brief.modelId,
    voiceId: brief.voiceId,
    script: brief.script,
    rightsEvidence: [...brief.rights.evidenceIds].sort(),
    voiceSettings: brief.voiceSettings ?? null
  });
  return `prod_${createHash("sha256").update(canonical).digest("hex").slice(0, 32)}`;
}
