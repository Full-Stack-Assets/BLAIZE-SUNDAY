import { z } from "zod";

const rightsStatusSchema = z.enum(["unknown", "pending_review", "verified", "restricted", "expired"]);

export const productionBriefSchema = z.object({
  assetId: z.string().trim().min(1).max(120),
  title: z.string().trim().min(1).max(255),
  assetType: z.enum(["narration", "song", "meditation", "podcast", "audiobook", "sound_bed", "voiceover"]),
  script: z.string().trim().min(1).max(200_000),
  voiceId: z.string().trim().min(1).max(255),
  modelId: z.string().trim().min(1).max(255),
  rights: z.object({
    status: rightsStatusSchema,
    evidenceIds: z.array(z.string().trim().min(1)),
    restrictions: z.array(z.string().trim().min(1)).optional(),
    expiresAt: z.string().datetime().nullable().optional()
  }),
  operatorApproved: z.boolean(),
  metadata: z.object({
    language: z.string().trim().min(2).max(32),
    category: z.string().trim().min(1).max(120).optional(),
    persona: z.string().trim().min(1).max(255).optional(),
    style: z.string().trim().min(1).max(1000).optional(),
    bpm: z.number().int().min(30).max(300).optional(),
    targetDurationSeconds: z.number().int().positive().max(14_400).optional(),
    source: z.enum(["direct", "songforge"]).optional()
  }),
  voiceSettings: z.object({
    stability: z.number().min(0).max(1).optional(),
    similarityBoost: z.number().min(0).max(1).optional(),
    style: z.number().min(0).max(1).optional(),
    useSpeakerBoost: z.boolean().optional()
  }).optional()
}).strict().superRefine((brief, context) => {
  if (brief.rights.status === "verified" && brief.rights.evidenceIds.length === 0) {
    context.addIssue({ code: "custom", path: ["rights", "evidenceIds"], message: "Verified rights require at least one evidence ID" });
  }
});

export const produceRequestSchema = z.object({
  commit: z.boolean().default(false),
  brief: productionBriefSchema
}).strict();
