import type { DerivativePlan, ProductionResult } from "./types";

export function planDerivatives(result: ProductionResult): DerivativePlan {
  const common: DerivativePlan["items"] = [
    { kind: "youtube", status: "planned", requiresApproval: true, notes: "Create a long-form or visualizer version from the approved master." },
    { kind: "shorts", status: "planned", requiresApproval: true, notes: "Extract concise vertical-video hooks after transcript timing is available." },
    { kind: "transcript", status: "planned", requiresApproval: true, notes: "Generate and verify a transcript before publication." },
    { kind: "bundle", status: "planned", requiresApproval: true, notes: "Package the master with approved supporting files and license terms." },
    { kind: "subscription", status: "planned", requiresApproval: true, notes: "Evaluate inclusion in the owned subscription library." }
  ];
  if (result.assetType !== "song") common.unshift({ kind: "podcast", status: "planned", requiresApproval: true, notes: "Prepare an episode package and feed metadata." });
  if (result.assetType === "song") {
    common.unshift({ kind: "instrumental", status: "planned", requiresApproval: true, notes: "Create only when a real instrumental source or provider output exists." });
    common.unshift({ kind: "stems", status: "planned", requiresApproval: true, notes: "Create only from actual provider-supplied stems; never infer stem availability." });
  }
  return { sourceAssetId: result.assetId, items: common };
}

export function evaluateReleaseReadiness(result: ProductionResult): { status: "blocked" | "approval_required"; reasons: string[] } {
  if (result.status !== "produced") return { status: "blocked", reasons: ["A real production output is required before release review"] };
  if (result.rightsStatus !== "verified") return { status: "blocked", reasons: ["Commercial rights are not verified"] };
  return { status: "approval_required", reasons: ["Production and rights gates passed; human publication approval remains required"] };
}
