export interface ParsedSongForgeScript {
  title: string;
  persona: string;
  style: string;
  bpm: number | null;
  targetDurationSeconds: number | null;
  lyrics: string;
  sections: Array<{ name: string; text: string }>;
}

function header(text: string, name: string): string | null {
  const match = text.match(new RegExp(`^#\\s*${name}\\s*:\\s*(.+)$`, "im"));
  return match?.[1]?.trim() ?? null;
}

export function parseSongForgeScript(text: string): ParsedSongForgeScript {
  const title = header(text, "TITLE");
  const persona = header(text, "PERSONA");
  const style = header(text, "STYLE");
  if (!title || !persona || !style) throw new Error("SongForge script must include TITLE, PERSONA, and STYLE headers");
  const firstSection = text.search(/^\[[^\]]+\]/m);
  if (firstSection < 0) throw new Error("SongForge script must include structured lyric sections");
  const lyrics = text.slice(firstSection).trim();
  if (!lyrics) throw new Error("SongForge lyrics are empty");
  const bpmMatch = style.match(/\b(\d{2,3})\s*BPM\b/i);
  const duration = header(text, "TARGET DURATION");
  let targetDurationSeconds: number | null = null;
  if (duration) {
    const match = duration.match(/^(\d+):(\d{2})$/);
    if (!match) throw new Error("TARGET DURATION must use M:SS format");
    targetDurationSeconds = Number(match[1]) * 60 + Number(match[2]);
  }
  const sections: Array<{ name: string; text: string }> = [];
  const matches = [...lyrics.matchAll(/^\[([^\]]+)\]\s*\n([\s\S]*?)(?=^\[[^\]]+\]|$)/gm)];
  for (const match of matches) sections.push({ name: match[1].trim(), text: match[2].trim() });
  if (sections.length === 0) throw new Error("No parseable SongForge sections were found");
  return { title, persona, style, bpm: bpmMatch ? Number(bpmMatch[1]) : null, targetDurationSeconds, lyrics, sections };
}
