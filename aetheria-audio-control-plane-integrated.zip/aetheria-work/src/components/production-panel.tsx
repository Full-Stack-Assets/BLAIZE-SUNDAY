"use client";

import { useState } from "react";

const example = JSON.stringify({
  assetId: "ASSET-001",
  title: "Approved production title",
  assetType: "narration",
  script: "Paste the approved production script here.",
  voiceId: "",
  modelId: "eleven_multilingual_v2",
  rights: { status: "pending_review", evidenceIds: [] },
  operatorApproved: false,
  metadata: { language: "en", source: "direct" }
}, null, 2);

export function ProductionPanel({ configured }: { configured: boolean }) {
  const [token, setToken] = useState("");
  const [brief, setBrief] = useState(example);
  const [status, setStatus] = useState("Ready for a dry-run production plan");
  const [running, setRunning] = useState(false);

  async function submit(commit: boolean) {
    if (!token) return setStatus("Enter the server-configured operator token.");
    let parsed: unknown;
    try { parsed = JSON.parse(brief); } catch { return setStatus("Production brief must be valid JSON."); }
    setRunning(true);
    setStatus(commit ? "Running approved live production…" : "Evaluating gates and planning production…");
    try {
      const response = await fetch("/api/produce", { method:"POST", headers:{authorization:`Bearer ${token}`,"content-type":"application/json"}, body:JSON.stringify({ commit, brief: parsed }) });
      const body = await response.json();
      if (!response.ok) throw new Error(body.error ?? body.result?.error?.message ?? "Production request failed");
      setStatus(`${body.result.status}: ${body.result.assetId}. Release state: ${body.releaseReadiness.status}.`);
    } catch (error) { setStatus(error instanceof Error ? error.message : "Production request failed"); }
    finally { setRunning(false); }
  }

  return <section className="production-panel" aria-labelledby="production-heading">
    <div><p className="eyebrow">Rights-gated production</p><h2 id="production-heading">Produce an approved asset</h2><p>Dry-run validates the brief and plans derivatives. Live generation requires verified rights, operator approval, and ElevenLabs configuration.</p></div>
    <label>Operator token<input type="password" value={token} onChange={(e)=>setToken(e.target.value)} autoComplete="off" /></label>
    <label>Production brief JSON<textarea value={brief} onChange={(e)=>setBrief(e.target.value)} rows={16} spellCheck={false} /></label>
    <div className="button-row"><button disabled={running} onClick={()=>submit(false)}>Validate and plan</button><button className="secondary" disabled={running || !configured} onClick={()=>submit(true)}>Generate with ElevenLabs</button></div>
    {!configured && <p className="note">Live generation is disabled until ELEVENLABS_API_KEY is configured.</p>}
    <p className="status" role="status">{status}</p>
  </section>;
}
