"use client";

import { useState } from "react";
import { captureOperatorEvent } from "@/analytics/posthog";

export function ImportPanel() {
  const [token, setToken] = useState("");
  const [status, setStatus] = useState("Ready for a dry run");
  const [running, setRunning] = useState(false);

  async function runImport(commit: boolean) {
    if (!token) { setStatus("Enter the operator token configured on the server."); return; }
    setRunning(true);
    setStatus(commit ? "Committing verified catalog records…" : "Reading catalog without writing…");
    captureOperatorEvent("catalog_import_started", { mode: commit ? "commit" : "dry_run" });
    try {
      const response = await fetch("/api/import/elevenlabs", { method: "POST", headers: { authorization: `Bearer ${token}`, "content-type": "application/json" }, body: JSON.stringify({ commit }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Import failed");
      setStatus(`${result.totalAssets} unique assets observed; ${result.written} written. ${result.blocked} remain blocked by gates.`);
      captureOperatorEvent("catalog_import_completed", { mode: result.writeStatus, total_assets: result.totalAssets, blocked: result.blocked });
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Import failed");
    } finally { setRunning(false); }
  }

  return (
    <section className="import-panel" aria-labelledby="import-heading">
      <div>
        <p className="eyebrow">Catalog onboarding</p>
        <h2 id="import-heading">Inventory ElevenLabs first</h2>
        <p>Dry run reads voices, generated history, Studio projects, and owned agents. It never writes or publishes.</p>
      </div>
      <label>
        Operator token
        <input type="password" value={token} onChange={(event) => setToken(event.target.value)} autoComplete="off" placeholder="Server-configured token" />
      </label>
      <div className="button-row">
        <button disabled={running} onClick={() => runImport(false)}>Run safe inventory</button>
        <button className="secondary" disabled={running} onClick={() => runImport(true)}>Commit to Airtable</button>
      </div>
      <p className="status" role="status">{status}</p>
    </section>
  );
}

