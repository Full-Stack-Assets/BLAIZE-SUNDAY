import { ImportPanel } from "./import-panel";
import { ProductionPanel } from "./production-panel";

export interface DashboardSummary { totalAssets: number; blocked: number; approvalRequired: number; ready: number; lastImportAt: string | null }
export interface IntegrationReadiness { elevenlabs: boolean; airtable: boolean; posthog: boolean }

function StatusDot({ ready }: { ready: boolean }) { return <span className={ready ? "dot ready" : "dot"} aria-hidden="true" />; }

export function Dashboard({ summary, readiness }: { summary: DashboardSummary; readiness: IntegrationReadiness }) {
  return (
    <main>
      <header className="hero">
        <div>
          <p className="eyebrow">Aetheria Audio Labs</p>
          <h1>Audio IP control plane</h1>
          <p className="lede">One truthful operating view for catalog provenance, rights, quality, distribution, and profitability.</p>
        </div>
        <div className="hero-mark" aria-label="System mode">SAFE<br /><strong>INGEST</strong></div>
      </header>

      <section className="metrics" aria-label="Catalog summary">
        <article><span>Observed assets</span><strong>{summary.totalAssets}</strong><small>API or verified export only</small></article>
        <article><span>Rights / QA blocked</span><strong>{summary.blocked}</strong><small>Cannot publish</small></article>
        <article><span>Awaiting approval</span><strong>{summary.approvalRequired}</strong><small>Human decision queue</small></article>
        <article><span>Ready</span><strong>{summary.ready}</strong><small>Approved for next action</small></article>
      </section>

      {summary.totalAssets === 0 && <section className="empty-state"><p className="eyebrow">Current truth</p><h2>No catalog data imported yet</h2><p>Revenue, conversion, and profitability remain intentionally blank until real source records are connected.</p></section>}

      <div className="grid">
        <ImportPanel />
        <ProductionPanel configured={readiness.elevenlabs} />
        <section className="connections wide" aria-labelledby="connections-heading">
          <p className="eyebrow">Connection readiness</p>
          <h2 id="connections-heading">Foundation systems</h2>
          <ul>
            <li><StatusDot ready={readiness.elevenlabs} /><span>ElevenLabs</span><strong>{readiness.elevenlabs ? "Configured" : "ElevenLabs not configured"}</strong></li>
            <li><StatusDot ready={readiness.airtable} /><span>Airtable</span><strong>{readiness.airtable ? "Configured" : "Not configured"}</strong></li>
            <li><StatusDot ready={readiness.posthog} /><span>PostHog</span><strong>{readiness.posthog ? "Configured" : "Not configured"}</strong></li>
          </ul>
          <p className="note">Music and Sound Effects require a manual ElevenLabs export manifest because the public history API does not enumerate them.</p>
        </section>
      </div>

      <section className="gates">
        <div><span>01</span><h3>Observed</h3><p>Source ID and timestamp captured.</p></div>
        <div><span>02</span><h3>Rights</h3><p>Evidence reviewed by a human.</p></div>
        <div><span>03</span><h3>Quality</h3><p>Metadata and audio checks pass.</p></div>
        <div><span>04</span><h3>Approval</h3><p>Publication remains explicitly gated.</p></div>
      </section>
    </main>
  );
}

