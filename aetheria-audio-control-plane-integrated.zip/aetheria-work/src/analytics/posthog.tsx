"use client";

import posthog from "posthog-js";
import { useEffect, type ReactNode } from "react";

export function AnalyticsProvider({ children, apiKey, host }: { children: ReactNode; apiKey?: string; host?: string }) {
  useEffect(() => {
    if (!apiKey || posthog.__loaded) return;
    posthog.init(apiKey, { api_host: host || "https://us.i.posthog.com", person_profiles: "identified_only", capture_pageview: true, autocapture: false });
  }, [apiKey, host]);
  return children;
}

export function captureOperatorEvent(event: "catalog_import_started" | "catalog_import_completed" | "approval_requested" | "exception_viewed", properties: Record<string, unknown> = {}) {
  if (posthog.__loaded) posthog.capture(event, properties);
}

