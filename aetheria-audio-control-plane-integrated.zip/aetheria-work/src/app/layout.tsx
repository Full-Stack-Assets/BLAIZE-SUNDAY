import type { Metadata } from "next";
import { AnalyticsProvider } from "@/analytics/posthog";
import "./globals.css";

export const metadata: Metadata = { title: "Aetheria Audio Control Plane", description: "Rights-aware operations for an autonomous audio IP catalog." };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><AnalyticsProvider apiKey={process.env.NEXT_PUBLIC_POSTHOG_KEY} host={process.env.NEXT_PUBLIC_POSTHOG_HOST}>{children}</AnalyticsProvider></body></html>;
}
