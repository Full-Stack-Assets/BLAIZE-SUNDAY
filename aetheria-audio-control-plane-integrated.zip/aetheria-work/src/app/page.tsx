import { Dashboard } from "@/components/dashboard";

export default function Home() {
  return <Dashboard
    summary={{ totalAssets: 0, blocked: 0, approvalRequired: 0, ready: 0, lastImportAt: null }}
    readiness={{
      elevenlabs: Boolean(process.env.ELEVENLABS_API_KEY),
      airtable: Boolean(process.env.AIRTABLE_TOKEN && process.env.AIRTABLE_BASE_ID),
      posthog: Boolean(process.env.NEXT_PUBLIC_POSTHOG_KEY)
    }}
  />;
}

