import { isAuthorized } from "@/security/operator-auth";
import { produceRequestSchema } from "@/production/schema";
import { runProduction } from "@/production/run-production";
import { planDerivatives, evaluateReleaseReadiness } from "@/production/derivatives";
import { createAgentCheckpoint } from "@/production/checkpoint";
import { AirtableClient } from "@/integrations/airtable/client";
import { mapProductionBundle } from "@/integrations/airtable/map-records";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(request: Request) {
  if (!isAuthorized(request, process.env.OPERATOR_TOKEN)) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const parsed = produceRequestSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "Invalid production request", issues: parsed.error.issues }, { status: 400 });
  const dryRun = parsed.data.commit !== true;
  if (!dryRun && !process.env.ELEVENLABS_API_KEY) return Response.json({ error: "ElevenLabs is not configured for live production" }, { status: 503 });
  const result = await runProduction(parsed.data.brief, { apiKey: process.env.ELEVENLABS_API_KEY ?? "", dryRun });
  const derivatives = planDerivatives(result);
  const releaseReadiness = evaluateReleaseReadiness(result);
  const checkpoint = createAgentCheckpoint(result, { assetId: parsed.data.brief.assetId, action: releaseReadiness.status === "approval_required" ? "review_release" : "resolve_blocker" });
  let airtableSync: Record<string, unknown> | null = null;
  if (parsed.data.commit && process.env.AIRTABLE_TOKEN && process.env.AIRTABLE_BASE_ID) {
    const client = new AirtableClient({ token: process.env.AIRTABLE_TOKEN, baseId: process.env.AIRTABLE_BASE_ID });
    const bundle = mapProductionBundle(parsed.data.brief, result);
    const assets = await client.upsertRecords(process.env.AIRTABLE_ASSETS_TABLE ?? "Assets", "ExternalKey", [bundle.asset], false);
    const rights = await client.upsertRecords(process.env.AIRTABLE_RIGHTS_TABLE ?? "Rights & Consent", "RightsRecordID", [bundle.rights], false);
    const jobs = await client.upsertRecords(process.env.AIRTABLE_JOBS_TABLE ?? "Production Jobs", "JobID", [bundle.job], false);
    const exception = bundle.exception ? await client.upsertRecords(process.env.AIRTABLE_EXCEPTIONS_TABLE ?? "Exceptions", "ExceptionID", [bundle.exception], false) : null;
    airtableSync = { assets, rights, jobs, exception };
  }
  const status = result.status === "failed" ? 502 : result.status === "blocked" ? 409 : 200;
  return Response.json({ result, derivatives, releaseReadiness, checkpoint, airtableSync }, { status });
}
