export const runtime = "nodejs";

export async function GET() {
  return Response.json({
    status: "ok",
    service: "aetheria-audio-control-plane",
    integrations: {
      elevenlabs: Boolean(process.env.ELEVENLABS_API_KEY),
      airtable: Boolean(process.env.AIRTABLE_TOKEN && process.env.AIRTABLE_BASE_ID),
      posthog: Boolean(process.env.NEXT_PUBLIC_POSTHOG_KEY),
      production: Boolean(process.env.ELEVENLABS_API_KEY && process.env.OPERATOR_TOKEN)
    }
  });
}

