import { parseManualManifest } from "@/import/manual-manifest";
import { AirtableClient } from "@/integrations/airtable/client";
import { isAuthorized } from "@/security/operator-auth";

export const runtime = "nodejs";

export async function POST(request: Request) {
  if (!isAuthorized(request, process.env.OPERATOR_TOKEN)) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const body = await request.json().catch(() => null);
  try {
    const assets = parseManualManifest(body?.manifest);
    const commit = body?.commit === true;
    if (commit && (!process.env.AIRTABLE_TOKEN || !process.env.AIRTABLE_BASE_ID)) {
      return Response.json({ error: "Airtable is required for a committed import" }, { status: 503 });
    }
    const airtable = new AirtableClient({ token: process.env.AIRTABLE_TOKEN ?? "dry-run", baseId: process.env.AIRTABLE_BASE_ID ?? "dry-run" });
    const sync = await airtable.upsertAssets(assets, !commit);
    return Response.json({ totalAssets: assets.length, writeStatus: commit ? "committed" : "dry_run", written: sync.written });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Invalid manifest" }, { status: 400 });
  }
}

