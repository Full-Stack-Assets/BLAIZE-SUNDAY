import { ElevenLabsClient } from "@/integrations/elevenlabs/client";
import { AirtableClient } from "@/integrations/airtable/client";
import { runElevenLabsImport } from "@/import/run-import";
import { isAuthorized } from "@/security/operator-auth";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(request: Request) {
  if (!isAuthorized(request, process.env.OPERATOR_TOKEN)) return Response.json({ error: "Unauthorized" }, { status: 401 });
  if (!process.env.ELEVENLABS_API_KEY) return Response.json({ error: "ElevenLabs is not configured" }, { status: 503 });

  const input = await request.json().catch(() => ({})) as { commit?: boolean };
  const commit = input.commit === true;
  if (commit && (!process.env.AIRTABLE_TOKEN || !process.env.AIRTABLE_BASE_ID)) {
    return Response.json({ error: "Airtable is required for a committed import" }, { status: 503 });
  }

  const elevenlabs = new ElevenLabsClient({ apiKey: process.env.ELEVENLABS_API_KEY });
  const airtable = new AirtableClient({ token: process.env.AIRTABLE_TOKEN ?? "dry-run", baseId: process.env.AIRTABLE_BASE_ID ?? "dry-run" });
  try {
    const summary = await runElevenLabsImport({ readCatalog: () => elevenlabs.listCatalog(), syncAssets: (assets, dryRun) => airtable.upsertAssets(assets, dryRun) }, { commit });
    return Response.json(summary);
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Import failed" }, { status: 502 });
  }
}

