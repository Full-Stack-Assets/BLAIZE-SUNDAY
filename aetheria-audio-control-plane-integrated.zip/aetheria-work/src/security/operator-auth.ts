import { timingSafeEqual } from "node:crypto";

export function isAuthorized(request: Request, expectedToken?: string): boolean {
  if (!expectedToken) return false;
  const supplied = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ?? "";
  const left = Buffer.from(supplied);
  const right = Buffer.from(expectedToken);
  return left.length === right.length && timingSafeEqual(left, right);
}

