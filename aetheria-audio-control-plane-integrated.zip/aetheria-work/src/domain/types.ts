export type SourceEvidence = "api_observed" | "user_export" | "user_attested" | "inferred";
export type AssetType = "voice" | "generation" | "studio_project" | "agent" | "music" | "sound_effect";
export type RightsStatus = "unknown" | "pending_review" | "verified" | "restricted" | "expired";

export interface CanonicalAsset {
  externalKey: string;
  sourcePlatform: "elevenlabs";
  sourceId: string;
  sourceEvidence: SourceEvidence;
  observedAt: string;
  assetType: AssetType;
  title: string;
  description?: string | null;
  createdAt?: string | null;
  voiceId?: string | null;
  modelId?: string | null;
  sourceCategory?: string | null;
  rightsStatus: RightsStatus;
  qualityScore: number | null;
  metadataComplete: boolean;
  demandScore: number | null;
  distributionFlexibility: number | null;
  rightsSimplicity: number | null;
  rawMetadata: Record<string, unknown>;
}

export interface RightsRecord {
  status: RightsStatus;
  evidenceIds: string[];
  restrictions?: string[];
  expiresAt?: string | null;
}

export interface GateDecision {
  status: "blocked" | "approval_required" | "ready";
  reasons: string[];
  requiredApproval: "rights" | "quality" | "publish" | null;
}

export interface CatalogReadResult {
  assets: CanonicalAsset[];
  warnings: string[];
}

