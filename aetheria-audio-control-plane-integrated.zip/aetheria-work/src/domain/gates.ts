import type { CanonicalAsset, GateDecision, RightsRecord } from "./types";

export function evaluateReleaseGate(asset: CanonicalAsset, rights: RightsRecord): GateDecision {
  const reasons: string[] = [];
  if (rights.status !== "verified" || rights.evidenceIds.length === 0) {
    reasons.push("Commercial rights are not verified");
  }
  if (rights.expiresAt && new Date(rights.expiresAt).getTime() <= Date.now()) {
    reasons.push("Rights evidence is expired");
  }
  if (asset.qualityScore === null || asset.qualityScore < 85) {
    reasons.push("Quality score has not passed the 85-point threshold");
  }
  if (!asset.metadataComplete) reasons.push("Required release metadata is incomplete");

  if (reasons.length > 0) {
    const rightsFailure = reasons.some((reason) => reason.toLowerCase().includes("rights"));
    return { status: "blocked", reasons, requiredApproval: rightsFailure ? "rights" : "quality" };
  }
  return {
    status: "approval_required",
    reasons: ["Automated gates passed; a human must approve publication"],
    requiredApproval: "publish"
  };
}

