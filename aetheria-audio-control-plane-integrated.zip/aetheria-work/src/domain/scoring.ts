import type { CanonicalAsset } from "./types";

export interface ReadinessScore {
  score: number | null;
  basis: "observed" | "insufficient_data";
  missing: string[];
}

export function scoreRevenueReadiness(asset: CanonicalAsset): ReadinessScore {
  const required = {
    qualityScore: asset.qualityScore,
    demandScore: asset.demandScore,
    distributionFlexibility: asset.distributionFlexibility,
    rightsSimplicity: asset.rightsSimplicity
  };
  const missing = Object.entries(required).filter(([, value]) => value === null).map(([key]) => key);
  if (missing.length > 0) return { score: null, basis: "insufficient_data", missing };

  const score = Math.round(
    asset.qualityScore! * 0.4 +
    asset.demandScore! * 0.3 +
    asset.distributionFlexibility! * 0.2 +
    asset.rightsSimplicity! * 0.05 +
    (asset.metadataComplete ? 100 : 0) * 0.05
  );
  return { score, basis: "observed", missing: [] };
}

