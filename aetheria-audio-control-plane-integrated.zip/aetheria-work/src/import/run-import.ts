import type { CanonicalAsset, CatalogReadResult } from "@/domain/types";
import { evaluateReleaseGate } from "@/domain/gates";
import type { SyncResult } from "@/integrations/airtable/client";

export interface ImportDependencies {
  readCatalog: () => Promise<CatalogReadResult>;
  syncAssets: (assets: CanonicalAsset[], dryRun: boolean) => Promise<SyncResult>;
}

export interface ImportSummary {
  totalAssets: number;
  countsByType: Record<string, number>;
  blocked: number;
  approvalRequired: number;
  warnings: string[];
  writeStatus: "dry_run" | "committed";
  written: number;
  importedAt: string;
}

export async function runElevenLabsImport(dependencies: ImportDependencies, options: { commit?: boolean } = {}): Promise<ImportSummary> {
  const catalog = await dependencies.readCatalog();
  const deduped = [...new Map(catalog.assets.map((record) => [record.externalKey, record])).values()];
  const decisions = deduped.map((record) => evaluateReleaseGate(record, { status: record.rightsStatus, evidenceIds: [] }));
  const countsByType = deduped.reduce<Record<string, number>>((counts, record) => {
    counts[record.assetType] = (counts[record.assetType] ?? 0) + 1;
    return counts;
  }, {});
  const dryRun = options.commit !== true;
  const sync = await dependencies.syncAssets(deduped, dryRun);
  return {
    totalAssets: deduped.length,
    countsByType,
    blocked: decisions.filter((item) => item.status === "blocked").length,
    approvalRequired: decisions.filter((item) => item.status === "approval_required").length,
    warnings: catalog.warnings,
    writeStatus: dryRun ? "dry_run" : "committed",
    written: sync.written,
    importedAt: new Date().toISOString()
  };
}

