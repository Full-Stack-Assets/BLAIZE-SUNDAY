import { z } from "zod";
import type { CanonicalAsset } from "@/domain/types";

const manifestSchema = z.object({
  version: z.literal(1),
  exportedAt: z.iso.datetime(),
  assets: z.array(z.object({
    type: z.enum(["music", "sound_effect"]),
    id: z.string().min(1).max(200),
    title: z.string().min(1).max(300),
    createdAt: z.iso.datetime().optional(),
    description: z.string().max(2000).optional(),
    modelId: z.string().max(200).optional()
  })).max(10000)
});

export function parseManualManifest(input: unknown): CanonicalAsset[] {
  const manifest = manifestSchema.parse(input);
  return manifest.assets.map((item) => ({
    externalKey: `elevenlabs:${item.type}:${item.id}`,
    sourcePlatform: "elevenlabs" as const,
    sourceId: item.id,
    sourceEvidence: "user_export" as const,
    observedAt: manifest.exportedAt,
    assetType: item.type,
    title: item.title,
    description: item.description ?? null,
    createdAt: item.createdAt ?? null,
    modelId: item.modelId ?? null,
    rightsStatus: "unknown" as const,
    qualityScore: null,
    metadataComplete: Boolean(item.title && item.createdAt && item.modelId),
    demandScore: null,
    distributionFlexibility: null,
    rightsSimplicity: null,
    rawMetadata: { manifestVersion: manifest.version }
  }));
}

