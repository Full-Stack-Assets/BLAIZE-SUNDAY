import type { CanonicalAsset } from "@/domain/types";
import { mapAssetRecord } from "./map-records";

type Fetcher = typeof fetch;
export interface SyncResult { planned: number; written: number; dryRun: boolean }

export class AirtableClient {
  private readonly token: string;
  private readonly baseId: string;
  private readonly tableName: string;
  private readonly fetcher: Fetcher;

  constructor(options: { token: string; baseId: string; tableName?: string; fetcher?: Fetcher }) {
    this.token = options.token;
    this.baseId = options.baseId;
    this.tableName = options.tableName ?? "Assets";
    this.fetcher = options.fetcher ?? fetch;
  }

  async upsertAssets(assets: CanonicalAsset[], dryRun = true): Promise<SyncResult> {
    if (dryRun) return { planned: assets.length, written: 0, dryRun: true };
    let written = 0;
    for (let index = 0; index < assets.length; index += 10) {
      const records = assets.slice(index, index + 10).map(mapAssetRecord);
      const response = await this.fetcher(`https://api.airtable.com/v0/${this.baseId}/${encodeURIComponent(this.tableName)}`, {
        method: "PATCH",
        headers: { authorization: `Bearer ${this.token}`, "content-type": "application/json" },
        body: JSON.stringify({ performUpsert: { fieldsToMergeOn: ["ExternalKey"] }, records, typecast: false })
      });
      if (!response.ok) throw new Error(`Airtable sync failed (${response.status})`);
      written += records.length;
    }
    return { planned: assets.length, written, dryRun: false };
  }
  async upsertRecords(tableName: string, mergeField: string, records: Array<{ fields: Record<string, string | number | boolean> }>, dryRun = true): Promise<SyncResult> {
    if (dryRun) return { planned: records.length, written: 0, dryRun: true };
    let written = 0;
    for (let index = 0; index < records.length; index += 10) {
      const batch = records.slice(index, index + 10);
      const response = await this.fetcher(`https://api.airtable.com/v0/${this.baseId}/${encodeURIComponent(tableName)}`, {
        method: "PATCH",
        headers: { authorization: `Bearer ${this.token}`, "content-type": "application/json" },
        body: JSON.stringify({ performUpsert: { fieldsToMergeOn: [mergeField] }, records: batch, typecast: false })
      });
      if (!response.ok) throw new Error(`Airtable sync failed for ${tableName} (${response.status})`);
      written += batch.length;
    }
    return { planned: records.length, written, dryRun: false };
  }

}

