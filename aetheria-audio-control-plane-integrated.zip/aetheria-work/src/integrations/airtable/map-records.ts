import type { CanonicalAsset } from "@/domain/types";

const blockedKey = /(api.?key|token|secret|password|authorization|cookie)/i;

function sanitizeMetadata(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(sanitizeMetadata);
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value).filter(([key]) => !blockedKey.test(key)).map(([key, nested]) => [key, sanitizeMetadata(nested)]));
  }
  return value;
}

export interface AirtableAssetRecord {
  fields: Record<string, string | number | boolean>;
}

export function mapAssetRecord(asset: CanonicalAsset): AirtableAssetRecord {
  return {
    fields: {
      ExternalKey: asset.externalKey,
      SourcePlatform: asset.sourcePlatform,
      SourceID: asset.sourceId,
      SourceEvidence: asset.sourceEvidence,
      ObservedAt: asset.observedAt,
      AssetType: asset.assetType,
      Title: asset.title,
      RightsStatus: asset.rightsStatus,
      QualityScore: asset.qualityScore ?? 0,
      HasQualityObservation: asset.qualityScore !== null,
      MetadataComplete: asset.metadataComplete,
      RawMetadata: JSON.stringify(sanitizeMetadata(asset.rawMetadata))
    }
  };
}


import type { ProductionBrief, ProductionResult } from "@/production/types";

export interface AirtableProductionBundle {
  asset: AirtableAssetRecord;
  rights: AirtableAssetRecord;
  job: AirtableAssetRecord;
  exception?: AirtableAssetRecord;
}

export function mapProductionBundle(brief: ProductionBrief, result: ProductionResult, observedAt = new Date().toISOString()): AirtableProductionBundle {
  const asset: AirtableAssetRecord = { fields: {
    ExternalKey: `aetheria:${brief.assetId}`,
    SourcePlatform: "aetheria",
    SourceID: brief.assetId,
    SourceEvidence: "user_attested",
    ObservedAt: observedAt,
    AssetType: brief.assetType,
    Title: brief.title,
    RightsStatus: brief.rights.status,
    QualityScore: 0,
    HasQualityObservation: false,
    MetadataComplete: Boolean(brief.title && brief.metadata.language),
    RawMetadata: JSON.stringify(sanitizeMetadata({ metadata: brief.metadata, modelId: brief.modelId, voiceId: brief.voiceId }))
  } };
  const rights: AirtableAssetRecord = { fields: {
    RightsRecordID: `rights:${brief.assetId}`,
    AssetExternalKey: `aetheria:${brief.assetId}`,
    Status: brief.rights.status,
    EvidenceLocation: brief.rights.evidenceIds.join(","),
    Restrictions: (brief.rights.restrictions ?? []).join("\n"),
    ExpirationDate: brief.rights.expiresAt ?? "",
    ReviewedBy: brief.operatorApproved ? "operator-approved" : "",
    ApprovedAt: brief.operatorApproved ? observedAt : ""
  } };
  const job: AirtableAssetRecord = { fields: {
    JobID: result.jobId,
    AssetExternalKey: `aetheria:${brief.assetId}`,
    Stage: result.status === "produced" ? "Complete" : result.status === "planned" ? "Generation Planned" : result.status,
    AttemptCount: 1,
    ErrorMessage: result.error?.message ?? "",
    StartedAt: observedAt,
    CompletedAt: result.status === "produced" || result.status === "failed" || result.status === "blocked" ? observedAt : "",
    RequiresHumanReview: result.status !== "produced"
  } };
  const exception = result.status === "blocked" || result.status === "failed" ? { fields: {
    ExceptionID: `exception:${result.jobId}`,
    RelatedExternalKey: `aetheria:${brief.assetId}`,
    Severity: result.status === "blocked" ? "High" : "Critical",
    ExceptionType: result.status === "blocked" ? "Rights" : "Production",
    Description: result.error?.message ?? result.gate.reasons.join("; "),
    RecommendedAction: result.status === "blocked" ? "Resolve rights or approval requirements before retrying." : "Review provider configuration and retryability before rerunning.",
    OwnerDecision: "",
    ClosedAt: ""
  } } : undefined;
  return { asset, rights, job, exception };
}
