import type { CanonicalAsset } from "@/domain/types";
import type { ElevenLabsAgent, ElevenLabsHistoryItem, ElevenLabsStudioProject, ElevenLabsVoice } from "./types";

const isoFromUnix = (value?: number) => value ? new Date(value * 1000).toISOString() : null;

export function normalizeVoice(item: ElevenLabsVoice, observedAt: string): CanonicalAsset {
  return {
    externalKey: `elevenlabs:voice:${item.voice_id}`,
    sourcePlatform: "elevenlabs",
    sourceId: item.voice_id,
    sourceEvidence: "api_observed",
    observedAt,
    assetType: "voice",
    title: item.name || `Voice ${item.voice_id.slice(0, 8)}`,
    description: item.description ?? null,
    sourceCategory: item.category ?? null,
    rightsStatus: "unknown",
    qualityScore: null,
    metadataComplete: Boolean(item.name && item.category),
    demandScore: null,
    distributionFlexibility: null,
    rightsSimplicity: null,
    rawMetadata: { category: item.category ?? null, labels: item.labels ?? {} }
  };
}

export function normalizeHistoryItem(item: ElevenLabsHistoryItem, observedAt: string): CanonicalAsset {
  return {
    externalKey: `elevenlabs:generation:${item.history_item_id}`,
    sourcePlatform: "elevenlabs",
    sourceId: item.history_item_id,
    sourceEvidence: "api_observed",
    observedAt,
    assetType: "generation",
    title: item.voice_name ? `${item.voice_name} generation` : `Generation ${item.history_item_id.slice(0, 8)}`,
    createdAt: isoFromUnix(item.date_unix),
    voiceId: item.voice_id ?? null,
    modelId: item.model_id ?? null,
    sourceCategory: item.source ?? null,
    rightsStatus: "unknown",
    qualityScore: null,
    metadataComplete: Boolean(item.voice_id && item.model_id && item.output_format),
    demandScore: null,
    distributionFlexibility: null,
    rightsSimplicity: null,
    rawMetadata: { source: item.source ?? null, contentType: item.content_type ?? null, outputFormat: item.output_format ?? null }
  };
}

export function normalizeProject(item: ElevenLabsStudioProject, observedAt: string): CanonicalAsset {
  return {
    externalKey: `elevenlabs:studio_project:${item.project_id}`,
    sourcePlatform: "elevenlabs",
    sourceId: item.project_id,
    sourceEvidence: "api_observed",
    observedAt,
    assetType: "studio_project",
    title: item.name || `Studio project ${item.project_id.slice(0, 8)}`,
    createdAt: isoFromUnix(item.create_date_unix),
    modelId: item.default_model_id ?? null,
    rightsStatus: "unknown",
    qualityScore: null,
    metadataComplete: Boolean(item.name),
    demandScore: null,
    distributionFlexibility: null,
    rightsSimplicity: null,
    rawMetadata: { canBeDownloaded: item.can_be_downloaded ?? null }
  };
}

export function normalizeAgent(item: ElevenLabsAgent, observedAt: string): CanonicalAsset {
  return {
    externalKey: `elevenlabs:agent:${item.agent_id}`,
    sourcePlatform: "elevenlabs",
    sourceId: item.agent_id,
    sourceEvidence: "api_observed",
    observedAt,
    assetType: "agent",
    title: item.name || `Agent ${item.agent_id.slice(0, 8)}`,
    createdAt: isoFromUnix(item.created_at_unix_secs),
    rightsStatus: "unknown",
    qualityScore: null,
    metadataComplete: Boolean(item.name),
    demandScore: null,
    distributionFlexibility: null,
    rightsSimplicity: null,
    rawMetadata: { tags: item.tags ?? [] }
  };
}

