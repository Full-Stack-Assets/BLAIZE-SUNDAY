import type { ProductionBrief } from "@/production/types";

export interface ElevenLabsSpeechRequest {
  text: string;
  model_id: string;
  voice_settings?: { stability?: number; similarity_boost?: number; style?: number; use_speaker_boost?: boolean };
}

export interface SpeechProviderResult {
  status: "planned" | "produced";
  outputUrl: null;
  contentType: string | null;
  bytes: number | null;
  audioBase64?: string;
}

export function buildElevenLabsSpeechRequest(brief: ProductionBrief): ElevenLabsSpeechRequest {
  const settings = brief.voiceSettings;
  return {
    text: brief.script,
    model_id: brief.modelId,
    ...(settings ? { voice_settings: {
      stability: settings.stability,
      similarity_boost: settings.similarityBoost,
      style: settings.style,
      use_speaker_boost: settings.useSpeakerBoost
    } } : {})
  };
}

export async function produceSpeech(
  brief: ProductionBrief,
  options: { apiKey: string; dryRun?: boolean; fetcher?: typeof fetch; outputFormat?: string }
): Promise<SpeechProviderResult> {
  if (options.dryRun !== false) return { status: "planned", outputUrl: null, contentType: null, bytes: null };
  if (!options.apiKey) throw Object.assign(new Error("ELEVENLABS_API_KEY is not configured"), { code: "CONFIGURATION_ERROR", retryable: false });
  const fetcher = options.fetcher ?? fetch;
  const outputFormat = options.outputFormat ?? "mp3_44100_128";
  const response = await fetcher(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(brief.voiceId)}?output_format=${encodeURIComponent(outputFormat)}`, {
    method: "POST",
    headers: { "xi-api-key": options.apiKey, "content-type": "application/json", accept: "audio/mpeg" },
    body: JSON.stringify(buildElevenLabsSpeechRequest(brief))
  });
  if (!response.ok) {
    const message = (await response.text()).slice(0, 500) || `ElevenLabs request failed (${response.status})`;
    throw Object.assign(new Error(message), { code: `ELEVENLABS_${response.status}`, retryable: response.status === 429 || response.status >= 500 });
  }
  const buffer = Buffer.from(await response.arrayBuffer());
  return {
    status: "produced",
    outputUrl: null,
    contentType: response.headers.get("content-type") ?? "audio/mpeg",
    bytes: buffer.byteLength,
    audioBase64: buffer.toString("base64")
  };
}
