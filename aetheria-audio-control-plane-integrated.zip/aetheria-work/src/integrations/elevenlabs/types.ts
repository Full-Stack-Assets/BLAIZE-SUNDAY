export interface ElevenLabsVoice {
  voice_id: string;
  name?: string;
  category?: string;
  description?: string | null;
  labels?: Record<string, string>;
}

export interface ElevenLabsHistoryItem {
  history_item_id: string;
  date_unix?: number;
  voice_id?: string | null;
  voice_name?: string | null;
  model_id?: string | null;
  source?: string | null;
  content_type?: string;
  output_format?: string | null;
}

export interface ElevenLabsStudioProject {
  project_id: string;
  name?: string;
  create_date_unix?: number;
  default_model_id?: string;
  can_be_downloaded?: boolean;
}

export interface ElevenLabsAgent {
  agent_id: string;
  name?: string;
  created_at_unix_secs?: number;
  tags?: string[];
}

