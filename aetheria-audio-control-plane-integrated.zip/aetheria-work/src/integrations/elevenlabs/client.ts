import type { CatalogReadResult } from "@/domain/types";
import { normalizeAgent, normalizeHistoryItem, normalizeProject, normalizeVoice } from "./normalize";
import type { ElevenLabsAgent, ElevenLabsHistoryItem, ElevenLabsStudioProject, ElevenLabsVoice } from "./types";

type Fetcher = typeof fetch;

export class ElevenLabsClient {
  private readonly apiKey: string;
  private readonly fetcher: Fetcher;
  private readonly baseUrl: string;

  constructor(options: { apiKey: string; fetcher?: Fetcher; baseUrl?: string }) {
    this.apiKey = options.apiKey;
    this.fetcher = options.fetcher ?? fetch;
    this.baseUrl = options.baseUrl ?? "https://api.elevenlabs.io";
  }

  private async getJson<T>(path: string): Promise<T> {
    const response = await this.fetcher(`${this.baseUrl}${path}`, {
      headers: { "xi-api-key": this.apiKey, accept: "application/json" },
      cache: "no-store"
    });
    if (!response.ok) throw new Error(`ElevenLabs request failed (${response.status})`);
    return response.json() as Promise<T>;
  }

  async listVoices(): Promise<ElevenLabsVoice[]> {
    const all: ElevenLabsVoice[] = [];
    let token: string | null = null;
    for (let page = 0; page < 100; page++) {
      const query = new URLSearchParams({ page_size: "100" });
      if (token) query.set("next_page_token", token);
      const data = await this.getJson<{ voices?: ElevenLabsVoice[]; has_more?: boolean; next_page_token?: string | null }>(`/v2/voices?${query}`);
      all.push(...(data.voices ?? []));
      if (!data.has_more || !data.next_page_token) break;
      token = data.next_page_token;
    }
    return all;
  }

  async listHistory(): Promise<ElevenLabsHistoryItem[]> {
    const all: ElevenLabsHistoryItem[] = [];
    let cursor: string | null = null;
    for (let page = 0; page < 100; page++) {
      const query = new URLSearchParams({ page_size: "1000" });
      if (cursor) query.set("start_after_history_item_id", cursor);
      const data = await this.getJson<{ history?: ElevenLabsHistoryItem[]; has_more?: boolean; last_history_item_id?: string | null }>(`/v1/history?${query}`);
      all.push(...(data.history ?? []));
      if (!data.has_more || !data.last_history_item_id) break;
      cursor = data.last_history_item_id;
    }
    return all;
  }

  async listProjects(): Promise<ElevenLabsStudioProject[]> {
    const data = await this.getJson<{ projects?: ElevenLabsStudioProject[] }>("/v1/studio");
    return data.projects ?? [];
  }

  async listAgents(): Promise<ElevenLabsAgent[]> {
    const all: ElevenLabsAgent[] = [];
    let cursor: string | null = null;
    for (let page = 0; page < 100; page++) {
      const query = new URLSearchParams({ page_size: "100", show_only_owned_agents: "true" });
      if (cursor) query.set("cursor", cursor);
      const data = await this.getJson<{ agents?: ElevenLabsAgent[]; has_more?: boolean; next_cursor?: string | null }>(`/v1/convai/agents?${query}`);
      all.push(...(data.agents ?? []));
      if (!data.has_more || !data.next_cursor) break;
      cursor = data.next_cursor;
    }
    return all;
  }

  async listCatalog(): Promise<CatalogReadResult> {
    const observedAt = new Date().toISOString();
    const warnings = ["ElevenLabs Music and Sound Effects are not enumerable through the public history API; import them with a manual export manifest."];
    const sources = await Promise.allSettled([this.listVoices(), this.listHistory(), this.listProjects(), this.listAgents()]);
    const labels = ["Voices", "Generated history", "Studio projects", "Agents"];
    sources.forEach((source, index) => { if (source.status === "rejected") warnings.push(`${labels[index]} unavailable during this import`); });
    const value = <T,>(index: number): T[] => sources[index]?.status === "fulfilled" ? (sources[index] as PromiseFulfilledResult<T[]>).value : [];
    return {
      assets: [
        ...value<ElevenLabsVoice>(0).map((item) => normalizeVoice(item, observedAt)),
        ...value<ElevenLabsHistoryItem>(1).map((item) => normalizeHistoryItem(item, observedAt)),
        ...value<ElevenLabsStudioProject>(2).map((item) => normalizeProject(item, observedAt)),
        ...value<ElevenLabsAgent>(3).map((item) => normalizeAgent(item, observedAt))
      ],
      warnings
    };
  }
}

