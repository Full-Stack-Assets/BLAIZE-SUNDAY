#!/usr/bin/env python3
"""
SongForge — autonomous agentic song-script factory.

Five AI personas (Country, Rock, Trap, Hip-Hop, Pop) take turns writing a
complete, original song script every 5 minutes. Each script opens with a
Suno-style creative prompt block (title + style/instrument/BPM directive),
followed by fully structured lyrics calibrated to land at 2:00–2:30 runtime.

Stdlib only. State lives on disk (ledger.json = originality memory).

Usage:
    export ANTHROPIC_API_KEY=sk-ant-...
    python3 songforge.py                 # run forever, one song / 5 min
    python3 songforge.py --once          # generate a single song and exit
    python3 songforge.py --interval 60   # custom cadence in seconds
    python3 songforge.py --persona trap  # pin one persona
"""

import argparse
import json
import os
import random
import re
import sys
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

# --- LLM backend: any OpenAI-compatible chat-completions API ----------------
# Default is Groq (fast, cheap, reliable). Works unchanged with OpenAI or
# OpenRouter by swapping the two env vars:
#   Groq:       LLM_BASE_URL=https://api.groq.com/openai/v1   LLM_MODEL=llama-3.3-70b-versatile
#   OpenAI:     LLM_BASE_URL=https://api.openai.com/v1        LLM_MODEL=gpt-4o-mini
#   OpenRouter: LLM_BASE_URL=https://openrouter.ai/api/v1     LLM_MODEL=<any>
# Auth key goes in LLM_API_KEY.
LLM_BASE_URL = os.environ.get("LLM_BASE_URL", "https://api.groq.com/openai/v1")
LLM_MODEL = os.environ.get("LLM_MODEL", "llama-3.3-70b-versatile")
OUT_DIR = Path("songs")
LEDGER = Path("ledger.json")
MEMORY_WINDOW = 40  # recent titles/themes/hooks kept to enforce originality

# ---------------------------------------------------------------------------
# Personas — each is a distinct writer with a voice, tics, and a duration
# model. Word budgets: sung genres deliver ~60–75 lyric-words/min once you
# account for held notes, instrumental turnarounds, and repeated hooks;
# rap/trap runs ~120–150 words/min with denser bars and shorter breaks.
# Budgets below target the 2:00–2:30 window for each style.
# ---------------------------------------------------------------------------
PERSONAS = {
    "country": {
        "name": "Dell 'Dusty' Harlan",
        "voice": (
            "A 54-year-old Texas honky-tonk lifer. Writes in concrete nouns — "
            "truck parts, county roads, church parking lots, names of real-feeling "
            "small towns. Every song has one twist of the knife in the final chorus. "
            "Never uses the word 'beer' in the hook (too easy). Loves internal rhyme "
            "and the classic country 'third-verse reversal'."
        ),
        "style_pool": [
            "outlaw country, telecaster twang, brushed snare, pedal steel weeping",
            "90s neo-traditional country, fiddle and steel, warm baritone lead",
            "country-rock stomper, slide guitar, gang vocals on the chorus",
            "front-porch acoustic country, dobro, close male-female harmony",
        ],
        "bpm_range": (72, 132),
        "word_budget": (150, 195),
        "vocal": ["weathered male baritone", "smoky female alto", "duet, male lead / female harmony"],
    },
    "rock": {
        "name": "Vic Marrow",
        "voice": (
            "Bar-band romantic who thinks 1978–1989 was the peak of civilization. "
            "Writes anthems built for a room of 200 people singing back the chorus. "
            "Big images: neon, engines, last trains, city skylines. Choruses must be "
            "shoutable by a drunk crowd on first listen — max 8 words per hook line. "
            "Always writes a pre-chorus that ramps."
        ),
        "style_pool": [
            "1980s bar-rock anthem, driving guitars, Hammond organ, big sing-along chorus",
            "heartland rock, chiming Rickenbacker, glockenspiel accents, E-Street energy",
            "hard rock strut, cowbell, dual lead guitars, stadium drums",
            "power-pop rock, crunchy chords, handclaps, harmonized hook",
        ],
        "bpm_range": (104, 148),
        "word_budget": (140, 185),
        "vocal": ["gritty male lead vocal", "raspy female rock belt", "male lead with gang-vocal chorus"],
    },
    "trap": {
        "name": "YG Cipher",
        "voice": (
            "Precision technician of modern trap. Obsessed with flow-switching — "
            "every verse must change cadence at least once, marked in the script. "
            "Ad-libs are compositional, written in (parentheses) on their own beat. "
            "Themes: ambition, paranoia, loyalty math, late-night city geometry. "
            "Hooks are hypnotic and repetition-driven, not wordy."
        ),
        "style_pool": [
            "dark trap, 808 slides, sparse piano loop, triplet hi-hats",
            "melodic trap, autotuned hook, ambient pad, hard-knocking 808s",
            "drill-influenced trap, sliding bass, eerie bell melody",
            "luxury trap, orchestral stabs, half-time bounce",
        ],
        "bpm_range": (130, 160),  # half-time feel
        "word_budget": (280, 360),
        "vocal": ["autotuned male melodic-rap vocal", "cold deadpan male delivery", "female rap lead, layered ad-libs"],
    },
    "hiphop": {
        "name": "Marlene 'Verse' Okafor",
        "voice": (
            "Golden-era craftsperson with a modern ear. Multisyllabic rhyme schemes, "
            "storytelling verses with a beginning-middle-turn, one extended metaphor "
            "carried across the whole song. Scratch-hook or sung-hook choruses. "
            "Believes verse two must always up the technical difficulty of verse one."
        ),
        "style_pool": [
            "boom-bap hip-hop, dusty soul sample, cracking snare, upright bass",
            "jazzy hip-hop, Rhodes chords, horn stabs, head-nod groove",
            "conscious hip-hop, gospel choir chops, live drums",
            "west-coast bounce, talkbox hook, funk bassline",
        ],
        "bpm_range": (84, 98),
        "word_budget": (300, 380),
        "vocal": ["confident female MC", "smooth male MC, sung hook", "two-MC trade-off verses"],
    },
    "memerap": {
        "name": "Milo 'Lowkey Liquid' Nguyen",
        "voice": (
            "A relentlessly cheerful ironic-flex rapper from a rainy northern city. "
            "Flexes absurd, deliberately unimpressive luxuries — a paid-off used sedan, "
            "a maxed-out retirement account, oat milk in bulk, a gym membership he "
            "actually uses — delivered with total deadpan confidence over huge bass. "
            "Comedy is the engine but the hooks are genuinely, annoyingly catchy: "
            "simple, repetitive, chantable, built to be memed. Ad-libs are goofy "
            "single words in (parentheses) — (yup) (sheesh) (nice). One verse per "
            "song must contain a weirdly sincere line about self-improvement or "
            "financial literacy, played completely straight. Never mean-spirited, "
            "never edgy — the joke is always on himself. Loves an abrupt beat-switch "
            "or a fake-out ending."
        ),
        "style_pool": [
            "comedy rap, huge sub-bass, minimal bouncy beat, whistling lead, deadpan playful male vocal",
            "meme rap, Y2K video-game synths, clap-heavy bounce, chantable hook",
            "ironic flex rap, brass-stab loop, springy 808 bounce, goofy ad-libs",
            "bubblegum bass rap, detuned toy-keyboard melody, thick low end, half-sung hook",
        ],
        "bpm_range": (95, 130),
        "word_budget": (230, 300),
        "vocal": ["deadpan playful male rap vocal", "nasal sing-song male rap delivery",
                  "bright male rap vocal with pitched-up hook doubles"],
    },
    "pop": {
        "name": "Juno Adler",
        "voice": (
            "Hyper-modern pop architect. Thinks in sections and payoffs: every song "
            "needs a 'moment' — a drop, a key lift, a stripped-down bridge, a vocal "
            "chop. Lyrics are emotionally direct, second-person, present tense. "
            "Pre-chorus tension is sacred. Loves a post-chorus vocal riff written "
            "out phonetically (oh-oh-oh patterns count as lyrics)."
        ),
        "style_pool": [
            "synth-pop, pulsing bass, sidechained pads, glossy female vocal",
            "dance-pop, four-on-the-floor, filtered build into a chorus drop",
            "bedroom pop, lo-fi drums, dreamy guitars, intimate double-tracked vocal",
            "80s-revival pop, gated reverb snare, DX7 keys, soaring hook",
        ],
        "bpm_range": (96, 124),
        "word_budget": (160, 210),
        "vocal": ["bright female pop lead", "breathy male falsetto lead", "female lead with stacked harmonies"],
    },
}

STRUCTURES = [
    "[Intro] [Verse 1] [Pre-Chorus] [Chorus] [Verse 2] [Pre-Chorus] [Chorus] [Bridge] [Final Chorus] [Outro]",
    "[Intro] [Verse 1] [Chorus] [Verse 2] [Chorus] [Bridge] [Chorus] [Outro]",
    "[Intro] [Hook] [Verse 1] [Hook] [Verse 2] [Hook] [Bridge] [Hook] [Outro]",
]

# Theme seeds the engine mutates so no two prompts start from the same place.
SETTINGS = [
    "a 24-hour diner off the interstate", "the last night of a county fair",
    "a rooftop water tower at 3 a.m.", "a pawn shop on the day it closes",
    "a laundromat during a blackout", "the parking lot after the game",
    "a ferry crossing in the fog", "a payphone that still works",
    "a mill town the week the mill reopens", "a car wash on a first date",
    "the cheap seats at a stadium show", "a lighthouse keeper's last shift",
    "an all-night gas station in a snowstorm", "the demolition of an old ballroom",
]
TENSIONS = [
    "leaving vs. staying", "a promise made too young", "money changing a friendship",
    "a second chance nobody asked for", "pride versus an apology",
    "fame arriving one year too late", "a rivalry turning into respect",
    "keeping a secret to protect someone", "outrunning your own reputation",
    "grief disguised as ambition", "a hometown that changed while you were gone",
]


def build_brief(persona_key: str, memory: dict) -> dict:
    p = PERSONAS[persona_key]
    style = random.choice(p["style_pool"])
    bpm = random.randint(*p["bpm_range"])
    vocal = random.choice(p["vocal"])
    lo, hi = p["word_budget"]
    return {
        "persona_key": persona_key,
        "persona": p["name"],
        "voice": p["voice"],
        "style": style,
        "bpm": bpm,
        "vocal": vocal,
        "structure": random.choice(STRUCTURES),
        "setting": random.choice(SETTINGS),
        "tension": random.choice(TENSIONS),
        "word_lo": lo,
        "word_hi": hi,
        "avoid_titles": memory.get("titles", [])[-MEMORY_WINDOW:],
        "avoid_hooks": memory.get("hooks", [])[-MEMORY_WINDOW:],
    }


def build_prompt(b: dict) -> str:
    return f"""You are {b['persona']}, an autonomous songwriting agent. Your creative identity:
{b['voice']}

Write ONE complete, fully original song script. Hard requirements:

1. HEADER BLOCK (first lines of output, exactly this shape):
   TITLE: <evocative title>
   PROMPT: "<Title>" — {b['style']}, {b['vocal']}, ~{b['bpm']} BPM
   TARGET RUNTIME: 2:00–2:30
   STRUCTURE: {b['structure']}

2. LYRICS: Follow the structure exactly, each section labeled in [brackets].
   Total lyric word count must land between {b['word_lo']} and {b['word_hi']} words
   (this calibrates the song to 2:00–2:30 at this tempo and genre density).
   Count repeated choruses at full weight — write them out every time, with the
   final chorus varied (a lift, a lyric twist, or an added counter-line).

3. PRODUCTION CUES: One short italicized production note under each section
   label (e.g., *drums drop out, vocal + organ only*).

4. CREATIVE ANCHORS for this song (weave in, don't state literally):
   - Setting energy: {b['setting']}
   - Emotional tension: {b['tension']}

5. ORIGINALITY: Do NOT reuse or closely echo any of these prior titles:
   {', '.join(b['avoid_titles']) if b['avoid_titles'] else '(none yet)'}
   Or these prior hook lines:
   {' | '.join(b['avoid_hooks']) if b['avoid_hooks'] else '(none yet)'}

6. After the script, on its own final line, output exactly:
   HOOK_LINE: <the single most repeated hook lyric>

Output the script only. No commentary."""


def call_llm(prompt: str, api_key: str, retries: int = 2) -> str:
    """OpenAI-compatible chat completion with basic retry/backoff."""
    body = json.dumps({
        "model": LLM_MODEL,
        "max_tokens": 2000,
        "temperature": 0.95,
        "messages": [{"role": "user", "content": prompt}],
    }).encode()
    req = urllib.request.Request(
        f"{LLM_BASE_URL}/chat/completions", data=body, method="POST",
        headers={"Content-Type": "application/json",
                 "Authorization": f"Bearer {api_key}"},
    )
    for attempt in range(retries + 1):
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                data = json.loads(r.read())
            return data["choices"][0]["message"]["content"]
        except Exception:
            if attempt == retries:
                raise
            time.sleep(2 ** attempt * 3)  # 3s, 6s


call_claude = call_llm  # backward-compat alias for songforge_audio


def load_memory() -> dict:
    if LEDGER.exists():
        return json.loads(LEDGER.read_text())
    return {"titles": [], "hooks": [], "count": 0}


def save_memory(mem: dict) -> None:
    LEDGER.write_text(json.dumps(mem, indent=2))


def extract(pattern: str, text: str) -> str:
    m = re.search(pattern, text)
    return m.group(1).strip() if m else ""


def lyric_word_count(text: str) -> int:
    """Count words in lyric lines only (skip header, section labels, cues)."""
    words = 0
    for line in text.splitlines():
        s = line.strip()
        if (not s or s.startswith(("TITLE:", "PROMPT:", "TARGET", "STRUCTURE:", "HOOK_LINE:", "["))
                or (s.startswith("*") and s.endswith("*"))):
            continue
        words += len(s.split())
    return words


def generate_one(persona_key: str, api_key: str, mem: dict) -> Path:
    brief = build_brief(persona_key, mem)
    script = call_claude(build_prompt(brief), api_key)

    title = extract(r"TITLE:\s*(.+)", script) or "untitled"
    hook = extract(r"HOOK_LINE:\s*(.+)", script)
    wc = lyric_word_count(script)

    # One retry if the duration budget missed badly (>15% off either edge).
    lo, hi = brief["word_lo"], brief["word_hi"]
    if wc < lo * 0.85 or wc > hi * 1.15:
        fix = (f"{build_prompt(brief)}\n\nYour previous draft was {wc} lyric words — "
               f"outside the {lo}-{hi} budget. Rewrite the same song tightened/expanded to fit.")
        script = call_claude(fix, api_key)
        title = extract(r"TITLE:\s*(.+)", script) or title
        hook = extract(r"HOOK_LINE:\s*(.+)", script) or hook
        wc = lyric_word_count(script)

    mem["titles"].append(title)
    if hook:
        mem["hooks"].append(hook)
    mem["titles"] = mem["titles"][-MEMORY_WINDOW:]
    mem["hooks"] = mem["hooks"][-MEMORY_WINDOW:]
    mem["count"] += 1
    save_memory(mem)

    OUT_DIR.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    slug = re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-")[:40] or "song"
    path = OUT_DIR / f"{stamp}_{persona_key}_{slug}.md"
    path.write_text(
        f"<!-- SongForge #{mem['count']} | persona: {brief['persona']} ({persona_key}) "
        f"| {brief['bpm']} BPM | lyric words: {wc} (budget {lo}-{hi}) -->\n\n{script}\n"
    )
    print(f"[{stamp}] #{mem['count']} {persona_key:>7} | {wc:>3}w | {title}")
    return path


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--once", action="store_true", help="generate one song and exit")
    ap.add_argument("--interval", type=int, default=300, help="seconds between songs (default 300)")
    ap.add_argument("--persona", choices=list(PERSONAS), help="pin a single persona")
    ap.add_argument("--max", type=int, default=0, help="stop after N songs (0 = forever)")
    args = ap.parse_args()

    api_key = os.environ.get("LLM_API_KEY")
    if not api_key:
        sys.exit("Set LLM_API_KEY first (Groq/OpenAI/OpenRouter key; see header).")

    mem = load_memory()
    rotation = list(PERSONAS)
    random.shuffle(rotation)
    i = 0
    while True:
        persona = args.persona or rotation[i % len(rotation)]
        try:
            generate_one(persona, api_key, mem)
        except Exception as e:  # log and keep the loop alive
            print(f"[error] {e}", file=sys.stderr)
        i += 1
        if args.once or (args.max and i >= args.max):
            break
        time.sleep(args.interval)


if __name__ == "__main__":
    main()
