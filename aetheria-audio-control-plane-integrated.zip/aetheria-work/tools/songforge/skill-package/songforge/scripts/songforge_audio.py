#!/usr/bin/env python3
"""
SongForge Audio — turns SongForge scripts into finished MP3s via ElevenLabs.

Pipeline per song (every 5 minutes):
  1. songforge.py writes the script (persona, header prompt, sectioned lyrics)
  2. Script is parsed into sections -> an Eleven Music v2 composition_plan
     (per-section lyrics, styles, and exact duration_ms summing to 2:00-2:30)
  3. POST /v1/music  -> full song MP3 with sung vocals
  4. (optional) Persona "radio DJ" intro drop via TTS -- this is where voice
     CLONES are used. Cloned voices speak (TTS); sung lead-vocal timbre is
     controlled by the style prompt, since the Music API doesn't take voice_ids.

Stdlib only. Requires: LLM_API_KEY, ELEVENLABS_API_KEY.

Usage:
    python3 songforge_audio.py --once                 # one full song w/ audio
    python3 songforge_audio.py                        # loop, 5-min cadence
    python3 songforge_audio.py --intro                # add spoken DJ intro
    python3 songforge_audio.py --clone "Nic" a.mp3 b.mp3   # clone a voice,
                                                      # prints voice_id, exits
    python3 songforge_audio.py --intro-voice <voice_id>    # use your clone
"""

import argparse
import io
import json
import mimetypes
import os
import random
import re
import sys
import time
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path

import songforge  # persona system, script generation, ledger

EL_BASE = "https://api.elevenlabs.io"
MUSIC_MODEL = "music_v2"
TTS_MODEL = "eleven_multilingual_v2"
DEFAULT_INTRO_VOICE = "JBFqnCBsd6RMkjVDRZzb"  # a stock EL voice; override with --intro-voice
AUDIO_DIR = Path("audio")

# Target runtimes per genre (seconds) inside the 120-150s window.
TARGET_SECONDS = {"country": 140, "rock": 145, "trap": 130, "hiphop": 140,
                  "pop": 135, "memerap": 125}

# How long each section type runs, as a weight (normalized to target).
SECTION_WEIGHTS = {
    "intro": 6, "verse": 22, "pre-chorus": 8, "chorus": 18,
    "hook": 14, "bridge": 12, "final chorus": 20, "outro": 8,
}

NEGATIVE_STYLES = {
    "country": ["EDM", "synthesizers", "trap drums"],
    "rock": ["lo-fi", "trap hi-hats", "acoustic ballad"],
    "trap": ["rock guitars", "country twang", "swing jazz"],
    "hiphop": ["EDM drop", "metal guitars", "country"],
    "pop": ["harsh distortion", "free jazz", "screamed vocals"],
    "memerap": ["dark", "aggressive", "sad", "serious ballad", "rock guitars"],
}


# --------------------------------------------------------------------------
# ElevenLabs HTTP helpers (stdlib only)
# --------------------------------------------------------------------------
def _el_key() -> str:
    key = os.environ.get("ELEVENLABS_API_KEY")
    if not key:
        sys.exit("Set ELEVENLABS_API_KEY first.")
    return key


def el_post_json(path: str, payload: dict) -> bytes:
    req = urllib.request.Request(
        EL_BASE + path,
        data=json.dumps(payload).encode(),
        method="POST",
        headers={"xi-api-key": _el_key(), "Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=600) as r:
            return r.read()
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"ElevenLabs {path} -> {e.code}: {e.read().decode()[:500]}") from e


def el_post_multipart(path: str, fields: dict, files: list) -> bytes:
    """files: list of (fieldname, filepath). Minimal multipart encoder."""
    boundary = uuid.uuid4().hex
    body = io.BytesIO()
    for k, v in fields.items():
        body.write(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"\r\n\r\n{v}\r\n".encode())
    for field, fp in files:
        p = Path(fp)
        ctype = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
        body.write(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{field}\"; "
                   f"filename=\"{p.name}\"\r\nContent-Type: {ctype}\r\n\r\n".encode())
        body.write(p.read_bytes())
        body.write(b"\r\n")
    body.write(f"--{boundary}--\r\n".encode())
    req = urllib.request.Request(
        EL_BASE + path, data=body.getvalue(), method="POST",
        headers={"xi-api-key": _el_key(),
                 "Content-Type": f"multipart/form-data; boundary={boundary}"},
    )
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            return r.read()
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"ElevenLabs {path} -> {e.code}: {e.read().decode()[:500]}") from e


# --------------------------------------------------------------------------
# Voice cloning (Instant Voice Clone) -- for spoken persona/DJ parts
# --------------------------------------------------------------------------
def clone_voice(name: str, sample_paths: list) -> str:
    """Create an instant voice clone from 1+ audio samples. Returns voice_id.
    Requires an ElevenLabs plan with IVC (Starter and up)."""
    resp = el_post_multipart(
        "/v1/voices/add",
        fields={"name": name},
        files=[("files", p) for p in sample_paths],
    )
    voice_id = json.loads(resp).get("voice_id", "")
    print(f"Cloned voice '{name}' -> voice_id: {voice_id}")
    return voice_id


def tts(text: str, voice_id: str) -> bytes:
    """Spoken audio (DJ intro / persona drop) in the given voice."""
    return el_post_json(
        f"/v1/text-to-speech/{voice_id}?output_format=mp3_44100_128",
        {"text": text, "model_id": TTS_MODEL,
         "voice_settings": {"stability": 0.4, "similarity_boost": 0.8, "style": 0.6}},
    )


# --------------------------------------------------------------------------
# Script -> composition plan
# --------------------------------------------------------------------------
def parse_sections(script: str) -> list:
    """Return [(label, lyrics)] from a SongForge script."""
    sections, label, buf = [], None, []
    for line in script.splitlines():
        s = line.strip()
        m = re.match(r"\[([^\]]+)\]", s)
        if m:
            if label:
                sections.append((label, "\n".join(buf).strip()))
            label, buf = m.group(1).strip(), []
            continue
        if (not label or not s or s.startswith(("TITLE:", "PROMPT:", "TARGET",
                "STRUCTURE:", "HOOK_LINE:")) or (s.startswith("*") and s.endswith("*"))):
            continue
        buf.append(s)
    if label:
        sections.append((label, "\n".join(buf).strip()))
    return sections


def build_composition_plan(script: str, brief_style: str, bpm: int,
                           vocal: str, persona_key: str) -> dict:
    sections = parse_sections(script)
    target = TARGET_SECONDS.get(persona_key, 135)

    weights = []
    for label, _ in sections:
        key = label.lower()
        w = next((v for k, v in SECTION_WEIGHTS.items() if k in key), 15)
        weights.append(w)
    total_w = sum(weights) or 1

    pos_global = [s.strip() for s in brief_style.split(",")] + [vocal, f"{bpm} BPM"]
    chunks = []
    for (label, lyrics), w in zip(sections, weights):
        dur = max(3000, int(target * 1000 * w / total_w))
        chunks.append({
            "text": lyrics if lyrics else f"({label}, instrumental)",
            "duration_ms": min(dur, 120000),
            "positive_styles": [label.lower()],
            "negative_styles": [],
            "context_adherence": "high",
        })
    return {
        "positive_global_styles": pos_global,
        "negative_global_styles": NEGATIVE_STYLES.get(persona_key, []),
        "chunks": chunks[:30],
    }


def compose_music(plan: dict) -> bytes:
    """Full song MP3 from a composition plan (sung vocals included)."""
    return el_post_json("/v1/music?output_format=mp3_44100_128",
                        {"composition_plan": plan, "model_id": MUSIC_MODEL})


# --------------------------------------------------------------------------
# Persona DJ intro (spoken, voice-cloneable)
# --------------------------------------------------------------------------
def dj_intro_text(persona_name: str, title: str, style: str, api_key: str) -> str:
    prompt = (f"You are {persona_name}, introducing your new song on late-night radio. "
              f"Write ONE spoken line, max 22 words, in character, introducing "
              f"\"{title}\" ({style}). Output the line only.")
    return songforge.call_llm(prompt, api_key).strip().strip('"')


# --------------------------------------------------------------------------
# Full pipeline
# --------------------------------------------------------------------------
def generate_full_song(persona_key: str, llm_key: str, mem: dict,
                       with_intro: bool, intro_voice: str) -> None:
    brief = songforge.build_brief(persona_key, mem)
    script = songforge.call_llm(songforge.build_prompt(brief), llm_key)
    title = songforge.extract(r"TITLE:\s*(.+)", script) or "untitled"
    hook = songforge.extract(r"HOOK_LINE:\s*(.+)", script)

    # ledger + script file (reuse songforge conventions)
    mem["titles"] = (mem.get("titles", []) + [title])[-songforge.MEMORY_WINDOW:]
    if hook:
        mem["hooks"] = (mem.get("hooks", []) + [hook])[-songforge.MEMORY_WINDOW:]
    mem["count"] = mem.get("count", 0) + 1
    songforge.save_memory(mem)

    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    slug = re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-")[:40] or "song"
    songforge.OUT_DIR.mkdir(exist_ok=True)
    AUDIO_DIR.mkdir(exist_ok=True)
    (songforge.OUT_DIR / f"{stamp}_{persona_key}_{slug}.md").write_text(script + "\n")

    # script -> composition plan -> music
    plan = build_composition_plan(script, brief["style"], brief["bpm"],
                                  brief["vocal"], persona_key)
    (AUDIO_DIR / f"{stamp}_{slug}_plan.json").write_text(json.dumps(plan, indent=2))
    try:
        mp3 = compose_music(plan)
    except RuntimeError as e:
        # bad_prompt/bad_composition_plan -> retry once on the simple prompt path
        print(f"[plan rejected] {e} -- retrying with simple prompt", file=sys.stderr)
        mp3 = el_post_json("/v1/music?output_format=mp3_44100_128", {
            "prompt": f"{brief['style']}, {brief['vocal']}, ~{brief['bpm']} BPM. "
                      f"A song titled '{title}'.",
            "music_length_ms": TARGET_SECONDS.get(persona_key, 135) * 1000,
            "model_id": MUSIC_MODEL,
        })
    song_path = AUDIO_DIR / f"{stamp}_{persona_key}_{slug}.mp3"
    song_path.write_bytes(mp3)

    if with_intro:
        line = dj_intro_text(brief["persona"], title, brief["style"], llm_key)
        intro_path = AUDIO_DIR / f"{stamp}_{persona_key}_{slug}_intro.mp3"
        intro_path.write_bytes(tts(line, intro_voice))
        print(f"    intro: \"{line}\" -> {intro_path.name}")

    secs = sum(c["duration_ms"] for c in plan["chunks"]) / 1000
    print(f"[{stamp}] #{mem['count']} {persona_key:>7} | {secs:5.1f}s plan | {title} -> {song_path.name}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--interval", type=int, default=300)
    ap.add_argument("--persona", choices=list(songforge.PERSONAS))
    ap.add_argument("--max", type=int, default=0)
    ap.add_argument("--intro", action="store_true", help="add spoken DJ intro via TTS")
    ap.add_argument("--intro-voice", default=DEFAULT_INTRO_VOICE,
                    help="voice_id for intros (use your clone's id)")
    ap.add_argument("--clone", nargs="+", metavar=("NAME", "SAMPLE"),
                    help="clone a voice from audio samples and exit")
    ap.add_argument("--from-script", metavar="FILE",
                    help="render audio from an existing script file (no LLM call); "
                         "requires --persona for style/duration mapping")
    args = ap.parse_args()

    if args.from_script:
        if not args.persona:
            sys.exit("--from-script requires --persona")
        _el_key()
        script = Path(args.from_script).read_text()
        title = songforge.extract(r"TITLE:\s*(.+)", script) or "untitled"
        style = songforge.extract(r"PROMPT:.*?—\s*(.+)", script) or "modern pop"
        bpm_m = re.search(r"~?(\d{2,3})\s*BPM", script)
        bpm = int(bpm_m.group(1)) if bpm_m else 110
        plan = build_composition_plan(script, style, bpm, "", args.persona)
        AUDIO_DIR.mkdir(exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
        slug = re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-")[:40] or "song"
        (AUDIO_DIR / f"{stamp}_{slug}_plan.json").write_text(json.dumps(plan, indent=2))
        out = AUDIO_DIR / f"{stamp}_{args.persona}_{slug}.mp3"
        out.write_bytes(compose_music(plan))
        print(f"rendered {sum(c['duration_ms'] for c in plan['chunks'])/1000:.1f}s -> {out}")
        return

    if args.clone:
        if len(args.clone) < 2:
            sys.exit("--clone NAME sample1.mp3 [sample2.mp3 ...]")
        clone_voice(args.clone[0], args.clone[1:])
        return

    llm_key = os.environ.get("LLM_API_KEY")
    if not llm_key:
        sys.exit("Set LLM_API_KEY first.")
    _el_key()  # fail fast if missing

    mem = songforge.load_memory()
    rotation = list(songforge.PERSONAS)
    random.shuffle(rotation)
    i = 0
    while True:
        persona = args.persona or rotation[i % len(rotation)]
        try:
            generate_full_song(persona, llm_key, mem, args.intro, args.intro_voice)
        except Exception as e:
            print(f"[error] {e}", file=sys.stderr)
        i += 1
        if args.once or (args.max and i >= args.max):
            break
        time.sleep(args.interval)


if __name__ == "__main__":
    main()
