# Aetheria Audio IP Control Plane

A deployable foundation for turning an existing ElevenLabs catalog into a rights-aware, measurable audio IP business. It imports real catalog metadata, records provenance, blocks unsafe releases, writes approved operational records to Airtable, and gives the operator one exception-oriented dashboard.

## What is working

- Read-only catalog inventory for ElevenLabs voices, generated history, Studio projects, and owned agents
- Strict manual-export ingestion for ElevenLabs Music and Sound Effects
- Canonical asset records with source ID, evidence class, and observation time
- Rights, metadata, and quality publication gates
- Airtable upserts by stable `ExternalKey`, with dry-run as the default
- Operator-token protection for import endpoints
- Conditional PostHog instrumentation; no event is sent without configuration
- Responsive Next.js operator dashboard with honest zero-data states
- Automated type-check, test, and production-build CI

ElevenLabs states that its generated-history endpoint excludes Music and Sound Effects, so those asset classes use the versioned manual manifest instead of pretending that API coverage exists. See the official [generated-items documentation](https://elevenlabs.io/docs/api-reference/history/list), [voice search documentation](https://elevenlabs.io/docs/api-reference/voices/search), and [agent listing documentation](https://elevenlabs.io/docs/api-reference/agents/list).

## Start locally

```bash
cp .env.example .env.local
npm install
npm run dev
```

Open `http://localhost:3000`. Configure `ELEVENLABS_API_KEY` and `OPERATOR_TOKEN` to run a safe inventory. Add Airtable settings only when ready to commit records.

## Verify

```bash
npm run typecheck
npm test
npm run build
```

## API

`GET /api/health` returns configuration readiness without secret values.

`POST /api/import/elevenlabs` requires `Authorization: Bearer <OPERATOR_TOKEN>` and accepts `{ "commit": false }`. Dry-run is the safe default. Setting `commit` to `true` requires Airtable configuration.

`POST /api/import/manual` accepts `{ "commit": false, "manifest": { ... } }`. The exact format is in `config/manual-manifest.schema.json`.

## Deliberate safety boundaries

This release does not create new audio, publish products, change prices, make payments, approve rights, send outreach, or delete assets. Those remain later adapters behind explicit approvals. It also does not display revenue until observed revenue records exist.

See [Operations](docs/OPERATIONS.md), [Data provenance](docs/DATA-PROVENANCE.md), and [Rights and approvals](docs/RIGHTS-AND-APPROVALS.md).


## Rights-gated production and SongForge

The control plane now includes a production-domain layer and authenticated `POST /api/produce` endpoint. It validates a canonical production brief, blocks generation until rights and operator approval pass, supports dry-run planning, calls ElevenLabs only in committed mode, proposes derivative products, and serializes a restart-safe checkpoint.

SongForge is integrated as a structured input format. Interactive songwriting stays in conversation and does not require an external LLM. The uploaded unattended batch utility is preserved under `tools/songforge/` but remains outside the web runtime and cannot bypass rights or publication gates. See [SongForge Integration](docs/SONGFORGE-INTEGRATION.md).
